plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.depthclock.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.depthclock.app"
        minSdk = 28
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    // Bundled on-device person segmentation (works offline, no Play services download)
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
    // Google's unbundled "any subject" model (downloaded by Play services); the bundled person model above is the fallback
    implementation("com.google.android.gms:play-services-mlkit-subject-segmentation:16.0.0-beta1")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
}

package com.depthclock.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.ceil

object Store {
    fun bgFile(ctx: Context) = File(ctx.filesDir, "bg.jpg")
    fun fgFile(ctx: Context) = File(ctx.filesDir, "fg.png")
    fun alphaFile(ctx: Context) = File(ctx.filesDir, "alpha.bin")
    fun overlayFile(ctx: Context) = File(ctx.filesDir, "overlay.png")

    fun loadOverlay(ctx: Context): Bitmap? =
        overlayFile(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun loadBg(ctx: Context): Bitmap? =
        bgFile(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun loadFg(ctx: Context): Bitmap? =
        fgFile(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
}

data class ProcessResult(val ok: Boolean, val depth: Boolean, val message: String)

object DepthProcessor {

    /**
     * Crops the photo to the screen shape, saves it as the background, then lets the AI cut
     * the subject out and saves that as a transparent PNG (the "depth" layer).
     * Must be called from a background thread.
     */
    fun process(ctx: Context, uri: Uri, screenW: Int, screenH: Int, s: ClockSettings): ProcessResult {
        try {
            val k = minOf(1f, 2400f / screenH)
            val tw = (screenW * k).toInt().coerceAtLeast(1)
            val th = (screenH * k).toInt().coerceAtLeast(1)

            val src = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val iw = info.size.width
                val ih = info.size.height
                val sc = maxOf(tw.toFloat() / iw, th.toFloat() / ih)
                if (sc < 1f) {
                    val nw = ceil(iw * sc).toInt().coerceAtLeast(tw)
                    val nh = ceil(ih * sc).toInt().coerceAtLeast(th)
                    decoder.setTargetSize(nw, nh)
                }
            }

            // Center-crop to the screen's aspect ratio
            val bg = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
            val sc = maxOf(tw.toFloat() / src.width, th.toFloat() / src.height)
            val dw = src.width * sc
            val dh = src.height * sc
            val dst = RectF((tw - dw) / 2f, (th - dh) / 2f, (tw + dw) / 2f, (th + dh) / 2f)
            Canvas(bg).drawBitmap(src, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            src.recycle()

            FileOutputStream(Store.bgFile(ctx)).use { bg.compress(Bitmap.CompressFormat.JPEG, 94, it) }

            val note = buildForeground(ctx, bg, s, runAi = true)
            bg.recycle()
            Prefs.bumpImage(ctx)
            return ProcessResult(true, Store.fgFile(ctx).exists(), note)
        } catch (e: Throwable) {
            return ProcessResult(false, false, e.message ?: e.javaClass.simpleName)
        }
    }

    /**
     * Re-cuts the saved photo. [fullAi] = run the AI again (engine changed, or you want a fresh try);
     * otherwise only the edge softness / shift is re-applied to the saved AI mask (instant).
     */
    fun recut(ctx: Context, s: ClockSettings, fullAi: Boolean): ProcessResult {
        try {
            val bg = Store.loadBg(ctx) ?: return ProcessResult(false, false, Lang.tr("Choose a photo first."))
            val note = buildForeground(ctx, bg, s, runAi = fullAi)
            bg.recycle()
            Prefs.bumpImage(ctx)
            return ProcessResult(true, Store.fgFile(ctx).exists(), note)
        } catch (e: Throwable) {
            return ProcessResult(false, false, e.message ?: e.javaClass.simpleName)
        }
    }

    private fun buildForeground(ctx: Context, bg: Bitmap, s: ClockSettings, runAi: Boolean): String {
        var raw: RawCut? = if (runAi) null else Cutter.load(Store.alphaFile(ctx))
        var failure = ""
        if (raw == null) {
            raw = Cutter.cut(bg, s.cutEngine)
            if (raw != null) {
                Cutter.save(raw, Store.alphaFile(ctx))
            } else {
                failure = Cutter.lastError
            }
        }
        if (raw == null) {
            Store.fgFile(ctx).delete()
            Store.alphaFile(ctx).delete()
            return if (failure.isEmpty() || failure == "no clear subject found") {
                Lang.tr("Photo set, but the AI found no clear subject, so the depth effect is off.")
            } else {
                Lang.trf("Photo set, but the AI cut-out failed (%s). If this is the first run, the Google model may still be downloading; connect to the internet and tap Re-cut.", failure)
            }
        }
        val fg = Cutter.applyAlpha(bg, raw, s.edgeSoft, s.edgeShift)
        FileOutputStream(Store.fgFile(ctx)).use { fg.compress(Bitmap.CompressFormat.PNG, 100, it) }
        fg.recycle()
        return Lang.trf("Depth layer ready (%s). Drag the preview to test it.", Lang.tr(raw.engine))
    }

    /**
     * Saves an image as the overlay layer. Images without real transparency are cut out by the AI
     * (when [ProcessResult] auto-cut is on), then empty borders are trimmed.
     */
    fun importOverlay(ctx: Context, uri: Uri, s: ClockSettings): ProcessResult {
        try {
            val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val longest = maxOf(info.size.width, info.size.height)
                if (longest > 2400) {
                    val k = 2400f / longest
                    decoder.setTargetSize(
                        (info.size.width * k).toInt().coerceAtLeast(1),
                        (info.size.height * k).toInt().coerceAtLeast(1)
                    )
                }
            }
            val transparent = Cutter.hasTransparency(bmp)
            var out: Bitmap = bmp
            val msg: String
            if (!transparent && s.overlayAutoCut) {
                val raw = Cutter.cut(bmp, s.cutEngine)
                if (raw != null) {
                    val cut = Cutter.applyAlpha(bmp, raw, s.edgeSoft, s.edgeShift)
                    out = Cutter.trimTransparent(cut)
                    msg = Lang.trf("AI cut the subject out of your image (%s) and added it as the overlay.", Lang.tr(raw.engine))
                } else {
                    msg = Lang.tr("Overlay added, but the AI found no clear subject to cut out, so it will cover the photo. Try a transparent PNG.")
                }
            } else if (transparent) {
                out = Cutter.trimTransparent(bmp)
                msg = Lang.tr("Overlay added above your photo.")
            } else {
                msg = Lang.tr("Overlay added, but this image has no transparency, so it will cover the photo. Turn on AI auto-cut or use a transparent PNG.")
            }
            FileOutputStream(Store.overlayFile(ctx)).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            if (out !== bmp) out.recycle()
            bmp.recycle()
            Prefs.bumpImage(ctx)
            return ProcessResult(true, false, msg)
        } catch (e: Throwable) {
            return ProcessResult(false, false, e.message ?: e.javaClass.simpleName)
        }
    }

    fun removeOverlay(ctx: Context) {
        Store.overlayFile(ctx).delete()
        Prefs.bumpImage(ctx)
    }
}

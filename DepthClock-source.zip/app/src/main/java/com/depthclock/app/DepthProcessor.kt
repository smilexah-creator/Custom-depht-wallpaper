package com.depthclock.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.io.File
import java.io.FileOutputStream
import kotlin.math.ceil

object Store {
    fun bgFile(ctx: Context) = File(ctx.filesDir, "bg.jpg")
    fun fgFile(ctx: Context) = File(ctx.filesDir, "fg.png")

    fun overlayFile(ctx: Context) = File(ctx.filesDir, "overlay.png")

    fun loadOverlay(ctx: Context): Bitmap? =
        overlayFile(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun loadBg(ctx: Context): Bitmap? =
        bgFile(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun loadFg(ctx: Context): Bitmap? =
        fgFile(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
}

data class ProcessResult(val ok: Boolean, val depth: Boolean, val message: String)

object DepthProcessor {

    /**
     * Crops the photo to the screen shape, saves it as the background, then
     * cuts out the person and saves that as a transparent PNG (the "depth" layer).
     * Must be called from a background thread.
     */
    fun process(ctx: Context, uri: Uri, screenW: Int, screenH: Int): ProcessResult {
        try {
            val k = minOf(1f, 2400f / screenH)
            val tw = (screenW * k).toInt().coerceAtLeast(1)
            val th = (screenH * k).toInt().coerceAtLeast(1)

            val src = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val iw = info.size.width
                val ih = info.size.height
                val s = maxOf(tw.toFloat() / iw, th.toFloat() / ih)
                if (s < 1f) {
                    val nw = ceil(iw * s).toInt().coerceAtLeast(tw)
                    val nh = ceil(ih * s).toInt().coerceAtLeast(th)
                    decoder.setTargetSize(nw, nh)
                }
            }

            // Center-crop to the screen's aspect ratio
            val bg = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
            val s = maxOf(tw.toFloat() / src.width, th.toFloat() / src.height)
            val dw = src.width * s
            val dh = src.height * s
            val dst = RectF((tw - dw) / 2f, (th - dh) / 2f, (tw + dw) / 2f, (th + dh) / 2f)
            Canvas(bg).drawBitmap(src, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            src.recycle()

            FileOutputStream(Store.bgFile(ctx)).use { bg.compress(Bitmap.CompressFormat.JPEG, 92, it) }

            var hasDepth = false
            var note = ""
            try {
                val opts = SelfieSegmenterOptions.Builder()
                    .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                    .build()
                val segmenter = Segmentation.getClient(opts)
                val mask = try {
                    Tasks.await(segmenter.process(InputImage.fromBitmap(bg, 0)))
                } finally {
                    segmenter.close()
                }

                val mw = mask.width
                val mh = mask.height
                val source = if (mw == bg.width && mh == bg.height) bg else Bitmap.createScaledBitmap(bg, mw, mh, true)
                val pixels = IntArray(mw * mh)
                source.getPixels(pixels, 0, mw, 0, 0, mw, mh)

                val buf = mask.buffer
                buf.rewind()
                var covered = 0
                for (i in pixels.indices) {
                    val conf = buf.getFloat()
                    val a = smooth((conf - 0.30f) / 0.45f)
                    if (a > 0.5f) covered++
                    pixels[i] = ((a * 255f).toInt() shl 24) or (pixels[i] and 0x00FFFFFF)
                }
                val frac = covered.toFloat() / pixels.size

                if (frac in 0.01f..0.92f) {
                    val fg = Bitmap.createBitmap(pixels, mw, mh, Bitmap.Config.ARGB_8888)
                    FileOutputStream(Store.fgFile(ctx)).use { fg.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    fg.recycle()
                    hasDepth = true
                    note = "Depth layer ready. Drag the preview to test it."
                } else {
                    Store.fgFile(ctx).delete()
                    note = "Photo set, but no person was found, so the depth effect is off. Try a photo with a person in it."
                }
            } catch (e: Exception) {
                Store.fgFile(ctx).delete()
                note = "Photo set, but subject detection failed (${e.message}). Depth effect is off."
            }

            bg.recycle()
            Prefs.bumpImage(ctx)
            return ProcessResult(true, hasDepth, note)
        } catch (e: Throwable) {
            return ProcessResult(false, false, e.message ?: e.javaClass.simpleName)
        }
    }

    /** Saves a (preferably transparent PNG) image as the overlay layer, keeping its alpha. */
    fun importOverlay(ctx: Context, uri: Uri): ProcessResult {
        try {
            val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val longest = maxOf(info.size.width, info.size.height)
                if (longest > 2400) {
                    val k = 2400f / longest
                    decoder.setTargetSize(
                        (info.size.width * k).toInt().coerceAtLeast(1),
                        (info.size.height * k).toInt().coerceAtLeast(1)
                    )
                }
            }
            FileOutputStream(Store.overlayFile(ctx)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val hasAlpha = bmp.hasAlpha()
            bmp.recycle()
            Prefs.bumpImage(ctx)
            val msg = if (hasAlpha) {
                "Overlay added above your photo."
            } else {
                "Overlay added, but this image has no transparency, so it will cover the photo. Use a transparent PNG."
            }
            return ProcessResult(true, false, msg)
        } catch (e: Throwable) {
            return ProcessResult(false, false, e.message ?: e.javaClass.simpleName)
        }
    }

    fun removeOverlay(ctx: Context) {
        Store.overlayFile(ctx).delete()
        Prefs.bumpImage(ctx)
    }

    private fun smooth(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }
}

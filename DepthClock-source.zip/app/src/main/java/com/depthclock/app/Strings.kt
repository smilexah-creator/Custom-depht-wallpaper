package com.depthclock.app

import android.content.Context
import java.util.Locale

/**
 * Tiny translation layer. The English text is the key; missing keys fall back to English.
 * Languages: "en" English, "ar" Arabic, "ary" Darija (Moroccan Arabic).
 */
object Lang {
    const val NOTE_FONTS = "Apple's own fonts (SF Pro, New York) are licensed and can't be bundled in an app. " +
        "These are matching styles built from the system fonts. If you own a font file, import it and it works here too. " +
        "Hold an imported font to remove it."
    const val NOTE_AI = "Auto uses Google's subject model, so it can cut out people, pets and objects, and falls back to the built-in " +
        "person model if that isn't available. The cut is then snapped to the real edges of your photo, stray blobs " +
        "are removed and pin-holes filled. The first run may need internet once to download Google's model."
    const val NOTE_OVERLAY = "Pick any image. A transparent PNG is used as-is. If the image has no transparency, the AI cuts the subject out " +
        "for you and trims the empty space, so it sits cleanly over your photo."
    const val NOTE_MODEL = "Google doesn't publish the size of its any-subject model. It is stored by Google Play services, " +
        "so it isn't counted in this app's storage. The built-in person model adds about 4.5 MB to the app."
    const val NOTE_TARGET_NEW = "The other screen will show your plain photo without the clock. After you tap Set, Android may also ask where to apply it; choose the same option."
    const val NOTE_TARGET_OLD = "On your Android version the app can't limit the wallpaper to one screen. Choose Home, Lock or both on the screen Android shows next."
    const val TIP_DRAG = "Tip: touch and drag the clock on the preview to move it. It snaps to the center."

    private const val PREFS = "depthclock_ui"
    val codes = listOf("en", "ar", "ary")

    @Volatile
    var code: String = "en"
        private set

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = p.getString("lang", null)
        code = if (saved != null && saved in codes) saved
        else if (Locale.getDefault().language == "ar") "ar" else "en"
    }

    fun set(ctx: Context, c: String) {
        code = c
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("lang", c).apply()
    }

    fun isRtl(): Boolean = code != "en"

    fun tr(s: String): String = when (code) {
        "ar" -> ar[s]
        "ary" -> ary[s]
        else -> null
    } ?: s

    /** Translate a template containing %s / %d and fill it in. */
    fun trf(key: String, vararg a: Any): String = String.format(Locale.US, tr(key), *a)

    // ---- date language (clock wallpaper): 0 device, 1 English, 2 Arabic, 3 Darija
    fun dateCode(dateLang: Int): String = when (dateLang) {
        1 -> "en"
        2 -> "ar"
        3 -> "ary"
        else -> if (Locale.getDefault().language == "ar") "ar" else "en"
    }

    fun localeFor(dateLang: Int): Locale = when (dateLang) {
        1 -> Locale.ENGLISH
        2 -> Locale("ar")
        3 -> Locale("ar", "MA")
        else -> Locale.getDefault()
    }

    fun ampm(isAm: Boolean, dateLang: Int): String =
        if (dateCode(dateLang) == "en") (if (isAm) "AM" else "PM") else (if (isAm) "ص" else "م")

    private val ar: Map<String, String> = mapOf(
        "A clock that lives behind your subject" to "ساعة تعيش خلف الشخص في صورتك",
        "Choose a photo to get started." to "اختر صورة للبدء.",
        "Photo set. No depth layer yet. Tap Re-cut with AI in the Depth tab." to "تم تعيين الصورة. لا توجد طبقة عمق بعد. اضغط «إعادة القص بالذكاء الاصطناعي» في تبويب العمق.",
        "Depth layer ready. Drag the clock to move it, or drag elsewhere to tilt." to "طبقة العمق جاهزة. اسحب الساعة لتحريكها، أو اسحب في مكان آخر للإمالة.",
        "Show the wallpaper on" to "عرض الخلفية على", "Both screens" to "الشاشتان معاً", "Home screen" to "الشاشة الرئيسية",
        "Lock screen" to "شاشة القفل", "Wallpaper screen" to "شاشة الخلفية", "Show on" to "العرض على",
        "Both" to "الاثنتان", "Home" to "الرئيسية", "Lock" to "القفل",
        NOTE_TARGET_NEW to "ستعرض الشاشة الأخرى صورتك العادية بدون الساعة. وبعد الضغط على تعيين قد يسألك أندرويد أين يطبقها؛ اختر نفس الخيار.",
        NOTE_TARGET_OLD to "في إصدار أندرويد لديك لا يمكن للتطبيق حصر الخلفية في شاشة واحدة. اختر الرئيسية أو القفل أو كليهما في الشاشة التي يعرضها أندرويد بعد ذلك.",
        "Choose photo" to "اختر صورة",
        "Set wallpaper" to "تعيين كخلفية",
        "Clock" to "الساعة", "Fonts" to "الخطوط", "Depth" to "العمق", "Overlay" to "التراكب", "More" to "المزيد",
        "Size & position" to "الحجم والموضع", "Color" to "اللون", "Time" to "الوقت", "Date" to "التاريخ",
        "Style" to "النمط", "Numerals" to "الأرقام", "Fine tuning" to "ضبط دقيق", "Depth effect" to "تأثير العمق",
        "AI cut-out" to "القص بالذكاء الاصطناعي", "Background" to "الخلفية", "Overlay image" to "صورة التراكب",
        "Behavior" to "السلوك", "Placement" to "الموضع", "Motion" to "الحركة", "Reset" to "إعادة", "About" to "حول",
        "Language" to "اللغة", "AI model" to "نموذج الذكاء الاصطناعي", "Storage" to "التخزين",
        "Size" to "الحجم", "Vertical position" to "الموضع العمودي", "Horizontal position" to "الموضع الأفقي",
        "Opacity" to "الشفافية", "Custom hue" to "درجة اللون", "Second color (Gradient style)" to "اللون الثاني (نمط التدرج)",
        "Soft shadow" to "ظل ناعم", "Stack hours over minutes" to "الساعات فوق الدقائق", "24-hour time" to "نظام 24 ساعة",
        "Leading zero" to "صفر في البداية", "Show AM / PM (12-hour)" to "إظهار ص / م (نظام 12 ساعة)",
        "Show date" to "إظهار التاريخ", "Position" to "الموضع", "Above" to "فوق", "Below" to "تحت", "Format" to "الصيغة",
        "Full" to "كامل", "Short" to "مختصر", "Day" to "اليوم", "Weekday" to "اسم اليوم", "Date size" to "حجم التاريخ",
        "UPPERCASE" to "أحرف كبيرة", "Use the clock's font" to "استخدام خط الساعة", "Date language" to "لغة التاريخ",
        "Device" to "الجهاز", "App language" to "لغة التطبيق",
        "Text style" to "نمط النص", "Solid" to "ممتلئ", "Gradient" to "تدرج", "Outline" to "حدود", "Glass" to "زجاجي",
        "+  Import a font file (.ttf / .otf)" to "+  استيراد ملف خط (.ttf / .otf)",
        NOTE_FONTS to "خطوط آبل (SF Pro وNew York) محمية بالترخيص ولا يمكن تضمينها في التطبيق. هذه أنماط مشابهة مبنية من خطوط النظام. إذا كان لديك ملف خط فاستورده وسيعمل هنا أيضاً. اضغط مطولاً على الخط المستورد لحذفه.",
        "Weight (system fonts)" to "السماكة (خطوط النظام)", "Auto" to "تلقائي", "Italic" to "مائل",
        "Letter spacing" to "تباعد الحروف", "Line gap (stacked)" to "المسافة بين السطرين",
        "Sans" to "سانس", "Rounded" to "مستدير", "Serif" to "سيريف", "Condensed" to "ضيق", "Mono" to "أحادي",
        "Fun" to "مرح", "Imported" to "مستورد",
        "Clock behind subject" to "الساعة خلف الشخص", "Tilt strength" to "قوة الإمالة", "Clock depth" to "عمق الساعة",
        "Back %d" to "خلف %d", "Front +%d" to "أمام +%d", "Middle" to "المنتصف",
        "Invert tilt direction" to "عكس اتجاه الإمالة", "Engine" to "المحرك", "Any subject" to "أي شيء", "Person" to "شخص",
        "Edge softness" to "نعومة الحواف", "Edge shift (shrink / grow)" to "إزاحة الحواف (تقليص / تكبير)",
        "Re-cut with AI" to "إعادة القص بالذكاء الاصطناعي",
        NOTE_AI to "الوضع التلقائي يستخدم نموذج Google للأشياء، فيمكنه قص الأشخاص والحيوانات والأغراض، ويعود إلى نموذج الأشخاص المدمج إن لم يكن متاحاً. بعدها تُضبط الحواف على حواف صورتك الحقيقية وتُزال البقع الشاردة وتُملأ الثقوب الصغيرة. قد يحتاج التشغيل الأول إلى الإنترنت مرة واحدة لتنزيل نموذج Google.",
        "Dim background (makes the subject pop)" to "تعتيم الخلفية (يُبرز الشخص)", "Color saturation" to "تشبع الألوان",
        "Add overlay" to "إضافة تراكب", "Remove" to "حذف",
        NOTE_OVERLAY to "اختر أي صورة. صورة PNG الشفافة تُستخدم كما هي. وإذا لم تكن الصورة شفافة فسيقص الذكاء الاصطناعي الشخص منها ويقص المساحة الفارغة لتظهر بشكل نظيف فوق صورتك.",
        "Show overlay" to "إظهار التراكب", "In front of subject" to "أمام الشخص",
        "AI auto-cut for opaque images" to "قص تلقائي بالذكاء الاصطناعي للصور غير الشفافة",
        "Left / right" to "يسار / يمين", "Up / down" to "أعلى / أسفل", "Rotation" to "التدوير",
        "Flip horizontally" to "قلب أفقي", "Overlay removed." to "تم حذف التراكب.",
        "Tilt smoothing (lower = snappier)" to "نعومة الإمالة (أقل = أسرع)", "Frame rate" to "معدل الإطارات",
        "30 fps (saves battery)" to "30 إطاراً (يوفر البطارية)", "Reset all settings" to "إعادة ضبط كل الإعدادات",
        "Reset all settings?" to "إعادة ضبط كل الإعدادات؟",
        "Your photo, overlay and imported fonts are kept." to "ستبقى صورتك والتراكب والخطوط المستوردة.",
        "Cancel" to "إلغاء",
        "Set it as a live wallpaper from the Set wallpaper button. All processing happens on your phone." to "عيّنه كخلفية حية من زر «تعيين كخلفية». تتم كل المعالجة على هاتفك.",
        "Person model (built in)" to "نموذج الأشخاص (مدمج)", "Any-subject model (Google)" to "نموذج أي شيء (Google)",
        "Last cut used" to "آخر قص استخدم", "App size" to "حجم التطبيق", "Photos & cut-outs" to "الصور والقصاصات",
        "Imported fonts" to "الخطوط المستوردة", "≈ 4.5 MB in the app" to "≈ 4.5 ميغابايت داخل التطبيق",
        "Managed by Google Play" to "تديره خدمات Google Play",
        "any-subject model" to "نموذج أي شيء (Google)", "person model" to "نموذج الأشخاص", "none yet" to "لا يوجد بعد",
        NOTE_MODEL to "لا تنشر Google حجم نموذج «أي شيء». يتم تخزينه عبر خدمات Google Play، لذلك لا يُحتسب ضمن مساحة هذا التطبيق. أما نموذج الأشخاص المدمج فيضيف نحو 4.5 ميغابايت إلى التطبيق.",
        TIP_DRAG to "نصيحة: المس الساعة في المعاينة واسحبها لتغيير موضعها. وتنجذب إلى المنتصف.",
        "Still working, one moment..." to "ما زلنا نعمل، لحظة...", "Font added" to "تمت إضافة الخط",
        "That isn't a usable font file" to "هذا الملف ليس خطاً صالحاً",
        "Open Settings > Wallpaper and pick Depth Clock" to "افتح الإعدادات > الخلفية واختر Depth Clock",
        "Processing your photo and cutting out the subject..." to "جارٍ معالجة صورتك وقص الشخص...",
        "Adding your overlay..." to "جارٍ إضافة التراكب...", "AI is cutting out your subject..." to "الذكاء الاصطناعي يقص الشخص...",
        "Refining the edges..." to "جارٍ تحسين الحواف...", "Choose a photo first." to "اختر صورة أولاً.",
        "Could not use that photo: %s" to "تعذر استخدام هذه الصورة: %s",
        "Could not use that image: %s" to "تعذر استخدام هذه الصورة: %s",
        "Could not re-cut: %s" to "تعذرت إعادة القص: %s",
        "Remove \"%s\"?" to "حذف «%s»؟",
        "Depth layer ready (%s). Drag the preview to test it." to "طبقة العمق جاهزة (%s). اسحب المعاينة لتجربتها.",
        "Photo set, but the AI found no clear subject, so the depth effect is off." to "تم تعيين الصورة، لكن الذكاء الاصطناعي لم يجد شخصاً واضحاً، لذلك تأثير العمق متوقف.",
        "Photo set, but the AI cut-out failed (%s). If this is the first run, the Google model may still be downloading; connect to the internet and tap Re-cut." to "تم تعيين الصورة، لكن القص بالذكاء الاصطناعي فشل (%s). إن كانت هذه أول مرة فقد يكون نموذج Google قيد التنزيل؛ اتصل بالإنترنت واضغط إعادة القص.",
        "AI cut the subject out of your image (%s) and added it as the overlay." to "قص الذكاء الاصطناعي الشخص من صورتك (%s) وأضافه كتراكب.",
        "Overlay added, but the AI found no clear subject to cut out, so it will cover the photo. Try a transparent PNG." to "تمت إضافة التراكب، لكن الذكاء الاصطناعي لم يجد شخصاً واضحاً ليقصه، لذلك سيغطي الصورة. جرّب صورة PNG شفافة.",
        "Overlay added above your photo." to "تمت إضافة التراكب فوق صورتك.",
        "Overlay added, but this image has no transparency, so it will cover the photo. Turn on AI auto-cut or use a transparent PNG." to "تمت إضافة التراكب، لكن هذه الصورة غير شفافة فستغطي الصورة. فعّل القص التلقائي أو استخدم PNG شفافاً."
    )

    private val ary: Map<String, String> = mapOf(
        "A clock that lives behind your subject" to "ساعة كاتعيش من ورا الشخص ديالك فالتصويرة",
        "Choose a photo to get started." to "اختار تصويرة باش تبدا.",
        "Photo set. No depth layer yet. Tap Re-cut with AI in the Depth tab." to "التصويرة تحطات. باقي ماكاينش العمق. ضغط على «عاود قص بالذكاء الاصطناعي» فتاب العمق.",
        "Depth layer ready. Drag the clock to move it, or drag elsewhere to tilt." to "العمق واجد. جر الساعة باش تحركها، ولا جر فبلاصة أخرى باش تميل.",
        "Show the wallpaper on" to "بين الخلفية فـ", "Both screens" to "جوج شاشات", "Home screen" to "الشاشة الرئيسية",
        "Lock screen" to "شاشة القفل", "Wallpaper screen" to "شاشة الخلفية", "Show on" to "بين فـ",
        "Both" to "جوج", "Home" to "الرئيسية", "Lock" to "القفل",
        NOTE_TARGET_NEW to "الشاشة الأخرى غادي تبين التصويرة ديالك عادية بلا الساعة. ومن بعد ما تضغط على تعيين يمكن أندرويد يسولك فين يطبقها؛ اختار نفس الخيار.",
        NOTE_TARGET_OLD to "فنسخة أندرويد ديالك التطبيق ما يقدرش يحصر الخلفية فشاشة وحدة. اختار الرئيسية ولا القفل ولا جوج فالشاشة اللي غايبين ليك أندرويد من بعد.",
        "Choose photo" to "اختار تصويرة",
        "Set wallpaper" to "حط الخلفية",
        "Clock" to "الساعة", "Fonts" to "الخطوط", "Depth" to "العمق", "Overlay" to "الطبقة", "More" to "زيد",
        "Size & position" to "الحجم والبلاصة", "Color" to "اللون", "Time" to "الوقت", "Date" to "التاريخ",
        "Style" to "الستيل", "Numerals" to "الأرقام", "Fine tuning" to "ظبط دقيق", "Depth effect" to "تأثير العمق",
        "AI cut-out" to "القص بالذكاء الاصطناعي", "Background" to "الخلفية", "Overlay image" to "تصويرة الطبقة",
        "Behavior" to "الطريقة", "Placement" to "البلاصة", "Motion" to "الحركة", "Reset" to "رجع", "About" to "على التطبيق",
        "Language" to "اللغة", "AI model" to "موديل الذكاء الاصطناعي", "Storage" to "التخزين",
        "Size" to "الحجم", "Vertical position" to "البلاصة (فوق / تحت)", "Horizontal position" to "البلاصة (يمين / يسار)",
        "Opacity" to "الشفافية", "Custom hue" to "درجة اللون", "Second color (Gradient style)" to "اللون التاني (ستيل التدرج)",
        "Soft shadow" to "ضل ناعم", "Stack hours over minutes" to "الساعات فوق الدقايق", "24-hour time" to "نظام 24 ساعة",
        "Leading zero" to "صفر فالبداية", "Show AM / PM (12-hour)" to "بين ص / م (نظام 12 ساعة)",
        "Show date" to "بين التاريخ", "Position" to "البلاصة", "Above" to "فوق", "Below" to "تحت", "Format" to "الصيغة",
        "Full" to "كامل", "Short" to "مختصر", "Day" to "النهار", "Weekday" to "سمية النهار", "Date size" to "حجم التاريخ",
        "UPPERCASE" to "حروف كبار", "Use the clock's font" to "استعمل الخط ديال الساعة", "Date language" to "لغة التاريخ",
        "Device" to "التيليفون", "App language" to "لغة التطبيق",
        "Text style" to "ستيل النص", "Solid" to "عادي", "Gradient" to "تدرج", "Outline" to "كونتور", "Glass" to "زجاجي",
        "+  Import a font file (.ttf / .otf)" to "+  زيد ملف خط (.ttf / .otf)",
        NOTE_FONTS to "الخطوط ديال أبل (SF Pro و New York) عندها رخصة وما يمكنش نحطوها فالتطبيق. هادو ستيلات قريبين ليهم مبنيين من خطوط السيستيم. إلا كان عندك ملف خط، زيدو وغادي يخدم هنا حتى هو. ضغط بزاف على الخط اللي زدتي باش تمسحو.",
        "Weight (system fonts)" to "الغلظة (خطوط السيستيم)", "Auto" to "أوتوماتيك", "Italic" to "مايل",
        "Letter spacing" to "المسافة بين الحروف", "Line gap (stacked)" to "المسافة بين السطرين",
        "Sans" to "سانس", "Rounded" to "مدور", "Serif" to "سيريف", "Condensed" to "ضيق", "Mono" to "مونو",
        "Fun" to "مرح", "Imported" to "مزيود",
        "Clock behind subject" to "الساعة من ورا الشخص", "Tilt strength" to "قوة الميلان", "Clock depth" to "عمق الساعة",
        "Back %d" to "ورا %d", "Front +%d" to "قدام +%d", "Middle" to "فالوسط",
        "Invert tilt direction" to "عكس اتجاه الميلان", "Engine" to "المحرك", "Any subject" to "أي حاجة", "Person" to "شخص",
        "Edge softness" to "نعومة الحواف", "Edge shift (shrink / grow)" to "إزاحة الحواف (تصغير / تكبير)",
        "Re-cut with AI" to "عاود قص بالذكاء الاصطناعي",
        NOTE_AI to "الوضع أوتوماتيك كايستعمل موديل ديال Google للحوايج، يعني يقدر يقص الناس والحيوانات والأغراض، وكايرجع للموديل ديال الأشخاص اللي فالتطبيق إلا ماكانش متوفر. من بعد الحواف كايتظبطو على حواف التصويرة الحقيقية، وكاتمسح البقع الزايدة وكايتعمرو الثقوب الصغار. أول مرة يمكن يحتاج الانترنت مرة وحدة باش يحمل موديل Google.",
        "Dim background (makes the subject pop)" to "عتّم الخلفية (باش يبان الشخص)", "Color saturation" to "تشبع الألوان",
        "Add overlay" to "زيد طبقة", "Remove" to "مسح",
        NOTE_OVERLAY to "اختار أي تصويرة. PNG شفاف كايتستعمل بحالو. وإلا ماكانتش شفافة، الذكاء الاصطناعي كايقص ليك الشخص منها وكايمسح الفراغ الزايد باش تبان نقية فوق التصويرة ديالك.",
        "Show overlay" to "بين الطبقة", "In front of subject" to "قدام الشخص",
        "AI auto-cut for opaque images" to "قص أوتوماتيكي بالذكاء الاصطناعي للتصاور اللي ماشي شفافة",
        "Left / right" to "ليسر / ليمن", "Up / down" to "فوق / تحت", "Rotation" to "الدوران",
        "Flip horizontally" to "قلب أفقي", "Overlay removed." to "الطبقة تمسحات.",
        "Tilt smoothing (lower = snappier)" to "نعومة الميلان (أقل = أسرع)", "Frame rate" to "عدد الصور فالثانية",
        "30 fps (saves battery)" to "30 فالثانية (كايوفر البطارية)", "Reset all settings" to "رجع كل الإعدادات",
        "Reset all settings?" to "ترجع كل الإعدادات؟",
        "Your photo, overlay and imported fonts are kept." to "التصويرة والطبقة والخطوط اللي زدتي غاتبقى.",
        "Cancel" to "الغي",
        "Set it as a live wallpaper from the Set wallpaper button. All processing happens on your phone." to "حطو كخلفية متحركة من الزر «حط الخلفية». كلشي كايتعالج فالتيليفون ديالك.",
        "Person model (built in)" to "موديل الأشخاص (فالتطبيق)", "Any-subject model (Google)" to "موديل أي حاجة (Google)",
        "Last cut used" to "آخر قص تستعمل", "App size" to "حجم التطبيق", "Photos & cut-outs" to "التصاور والقصات",
        "Imported fonts" to "الخطوط اللي زدتي", "≈ 4.5 MB in the app" to "≈ 4.5 ميغا فالتطبيق",
        "Managed by Google Play" to "كايديرو Google Play",
        "any-subject model" to "موديل أي حاجة (Google)", "person model" to "موديل الأشخاص", "none yet" to "باقي والو",
        NOTE_MODEL to "Google ماكاتنشرش الحجم ديال موديل «أي حاجة». كايتخزن عبر خدمات Google Play، يعني ماكايتحسبش فمساحة هاد التطبيق. أما موديل الأشخاص اللي فالتطبيق كايزيد حوالي 4.5 ميغا.",
        TIP_DRAG to "نصيحة: لمس الساعة فالمعاينة وجرها باش تبدل البلاصة ديالها. وكاتلصق فالوسط.",
        "Still working, one moment..." to "باقي كانخدمو، تسنى شوية...", "Font added" to "الخط تزاد",
        "That isn't a usable font file" to "هاد الملف ماشي خط صالح",
        "Open Settings > Wallpaper and pick Depth Clock" to "حل الإعدادات > الخلفية واختار Depth Clock",
        "Processing your photo and cutting out the subject..." to "كانعالج التصويرة وكانقص الشخص...",
        "Adding your overlay..." to "كانزيد الطبقة...", "AI is cutting out your subject..." to "الذكاء الاصطناعي كايقص الشخص...",
        "Refining the edges..." to "كانحسن الحواف...", "Choose a photo first." to "اختار تصويرة الأول.",
        "Could not use that photo: %s" to "ماقدرناش نستعملو هاد التصويرة: %s",
        "Could not use that image: %s" to "ماقدرناش نستعملو هاد التصويرة: %s",
        "Could not re-cut: %s" to "ماقدرناش نعاودو القص: %s",
        "Remove \"%s\"?" to "مسح «%s»؟",
        "Depth layer ready (%s). Drag the preview to test it." to "العمق واجد (%s). جر المعاينة باش تجربو.",
        "Photo set, but the AI found no clear subject, so the depth effect is off." to "التصويرة تحطات، ولكن الذكاء الاصطناعي ماحصلش شخص واضح، عليه تأثير العمق طافي.",
        "Photo set, but the AI cut-out failed (%s). If this is the first run, the Google model may still be downloading; connect to the internet and tap Re-cut." to "التصويرة تحطات، ولكن القص بالذكاء الاصطناعي فشل (%s). إلا كانت هادي أول مرة يمكن موديل Google مازال كايتحمل؛ وصل بالانترنت وضغط على عاود القص.",
        "AI cut the subject out of your image (%s) and added it as the overlay." to "الذكاء الاصطناعي قص الشخص من التصويرة ديالك (%s) وزادو كطبقة.",
        "Overlay added, but the AI found no clear subject to cut out, so it will cover the photo. Try a transparent PNG." to "الطبقة تزادت، ولكن الذكاء الاصطناعي ماحصلش شخص واضح يقصو، عليه غاتغطي التصويرة. جرب PNG شفاف.",
        "Overlay added above your photo." to "الطبقة تزادت فوق التصويرة ديالك.",
        "Overlay added, but this image has no transparency, so it will cover the photo. Turn on AI auto-cut or use a transparent PNG." to "الطبقة تزادت، ولكن هاد التصويرة ماشي شفافة وغاتغطي التصويرة. شعل القص الأوتوماتيكي ولا استعمل PNG شفاف."
    )
}

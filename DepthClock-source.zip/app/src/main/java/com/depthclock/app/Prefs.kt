package com.depthclock.app

import android.content.Context
import android.graphics.Color

data class ClockSettings(
    var font: Int = 1,
    var sizePct: Int = 55,       // 0..100
    var color: Int = Color.WHITE,
    var opacity: Int = 100,      // 20..100
    var stacked: Boolean = true, // hours over minutes, like iOS
    var use24h: Boolean = true,
    var showDate: Boolean = true,
    var posY: Int = 24,          // vertical center of clock, % of screen height
    var shadow: Boolean = true,
    var depthEnabled: Boolean = true,
    var parallax: Int = 100,     // 0..200 % tilt strength
    var overlayEnabled: Boolean = true,
    var overlayFront: Boolean = false, // true = in front of the subject too
    var overlayOpacity: Int = 100,     // 0..100
    var overlayScale: Int = 100,       // 10..200 % of "fit to screen"
    var overlayX: Int = 50,            // center, % of screen width
    var overlayY: Int = 50             // center, % of screen height
)

object Prefs {
    const val NAME = "depthclock"
    const val KEY_IMG_VER = "imgVer"

    fun load(ctx: Context): ClockSettings {
        val p = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        val d = ClockSettings()
        return ClockSettings(
            font = p.getInt("font", d.font).coerceIn(0, Fonts.names.size - 1),
            sizePct = p.getInt("sizePct", d.sizePct).coerceIn(0, 100),
            color = p.getInt("color", d.color),
            opacity = p.getInt("opacity", d.opacity).coerceIn(20, 100),
            stacked = p.getBoolean("stacked", d.stacked),
            use24h = p.getBoolean("use24h", d.use24h),
            showDate = p.getBoolean("showDate", d.showDate),
            posY = p.getInt("posY", d.posY).coerceIn(5, 90),
            shadow = p.getBoolean("shadow", d.shadow),
            depthEnabled = p.getBoolean("depthEnabled", d.depthEnabled),
            parallax = p.getInt("parallax", d.parallax).coerceIn(0, 200),
            overlayEnabled = p.getBoolean("overlayEnabled", d.overlayEnabled),
            overlayFront = p.getBoolean("overlayFront", d.overlayFront),
            overlayOpacity = p.getInt("overlayOpacity", d.overlayOpacity).coerceIn(0, 100),
            overlayScale = p.getInt("overlayScale", d.overlayScale).coerceIn(10, 200),
            overlayX = p.getInt("overlayX", d.overlayX).coerceIn(0, 100),
            overlayY = p.getInt("overlayY", d.overlayY).coerceIn(0, 100)
        )
    }

    fun save(ctx: Context, s: ClockSettings) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putInt("font", s.font)
            .putInt("sizePct", s.sizePct)
            .putInt("color", s.color)
            .putInt("opacity", s.opacity)
            .putBoolean("stacked", s.stacked)
            .putBoolean("use24h", s.use24h)
            .putBoolean("showDate", s.showDate)
            .putInt("posY", s.posY)
            .putBoolean("shadow", s.shadow)
            .putBoolean("depthEnabled", s.depthEnabled)
            .putInt("parallax", s.parallax)
            .putBoolean("overlayEnabled", s.overlayEnabled)
            .putBoolean("overlayFront", s.overlayFront)
            .putInt("overlayOpacity", s.overlayOpacity)
            .putInt("overlayScale", s.overlayScale)
            .putInt("overlayX", s.overlayX)
            .putInt("overlayY", s.overlayY)
            .apply()
    }

    /** Tells the running wallpaper that a new photo/depth layer is on disk. */
    fun bumpImage(ctx: Context) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putLong(KEY_IMG_VER, System.currentTimeMillis())
            .apply()
    }
}

package com.depthclock.app

import android.content.Context
import android.graphics.Color

data class ClockSettings(
    // --- clock look
    var fontId: String = Fonts.DEFAULT_ID,
    var weight: Int = 0,              // 0 = font's own weight, else 100..900
    var italic: Boolean = false,
    var spacing: Int = 0,             // letter spacing, -5..30 (1/100 em)
    var lineGap: Int = 10,            // gap between hours and minutes, 0..40 %
    var textStyle: Int = 0,           // 0 solid, 1 gradient, 2 outline, 3 glass
    var numerals: Int = 0,            // index into Numerals
    var sizePct: Int = 55,            // 0..100
    var color: Int = Color.WHITE,
    var color2: Int = 0xFF7AA2FF.toInt(),
    var opacity: Int = 100,           // 20..100
    var shadow: Boolean = true,
    // --- time
    var stacked: Boolean = true,
    var use24h: Boolean = true,
    var leadingZero: Boolean = true,
    var showAmPm: Boolean = true,
    // --- date
    var showDate: Boolean = true,
    var datePos: Int = 0,             // 0 above, 1 below
    var dateFormat: Int = 0,          // 0 full, 1 short, 2 day only, 3 weekday only
    var dateSize: Int = 100,          // 50..200
    var dateUpper: Boolean = false,
    var dateClockFont: Boolean = false,
    var dateLang: Int = 0,            // 0 device, 1 English, 2 Arabic, 3 Darija
    // --- position
    var posY: Int = 24,               // % of screen height
    var posX: Int = 50,               // % of screen width
    // --- depth
    var depthEnabled: Boolean = true,
    var parallax: Int = 100,          // 0..200
    var clockDepth: Int = 0,          // -100..100
    var invertTilt: Boolean = false,
    var smooth: Int = 15,             // sensor filter, 4..60
    var fps30: Boolean = false,
    var target: Int = 0,              // wallpaper screen: 0 both, 1 home, 2 lock
    // --- AI cut-out
    var cutEngine: Int = 0,           // 0 auto, 1 any subject, 2 person
    var edgeSoft: Int = 25,           // 0..100
    var edgeShift: Int = 0,           // -50..50 (negative shrinks the cut-out)
    // --- background
    var bgDim: Int = 0,               // 0..70
    var bgSat: Int = 100,             // 0..200
    // --- overlay
    var overlayEnabled: Boolean = true,
    var overlayFront: Boolean = false,
    var overlayOpacity: Int = 100,
    var overlayScale: Int = 100,
    var overlayX: Int = 50,
    var overlayY: Int = 50,
    var overlayRotation: Int = 0,     // -180..180
    var overlayFlip: Boolean = false,
    var overlayAutoCut: Boolean = true
)

object Prefs {
    const val NAME = "depthclock"
    const val KEY_IMG_VER = "imgVer"

    fun load(ctx: Context): ClockSettings {
        val p = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        val d = ClockSettings()
        return ClockSettings(
            fontId = p.getString("fontId", d.fontId) ?: d.fontId,
            weight = p.getInt("weight", d.weight).coerceIn(0, 900),
            italic = p.getBoolean("italic", d.italic),
            spacing = p.getInt("spacing", d.spacing).coerceIn(-5, 30),
            lineGap = p.getInt("lineGap", d.lineGap).coerceIn(0, 40),
            textStyle = p.getInt("textStyle", d.textStyle).coerceIn(0, 3),
            numerals = p.getInt("numerals", d.numerals).coerceIn(0, Numerals.count - 1),
            sizePct = p.getInt("sizePct", d.sizePct).coerceIn(0, 100),
            color = p.getInt("color", d.color),
            color2 = p.getInt("color2", d.color2),
            opacity = p.getInt("opacity", d.opacity).coerceIn(20, 100),
            shadow = p.getBoolean("shadow", d.shadow),
            stacked = p.getBoolean("stacked", d.stacked),
            use24h = p.getBoolean("use24h", d.use24h),
            leadingZero = p.getBoolean("leadingZero", d.leadingZero),
            showAmPm = p.getBoolean("showAmPm", d.showAmPm),
            showDate = p.getBoolean("showDate", d.showDate),
            datePos = p.getInt("datePos", d.datePos).coerceIn(0, 1),
            dateFormat = p.getInt("dateFormat", d.dateFormat).coerceIn(0, 3),
            dateSize = p.getInt("dateSize", d.dateSize).coerceIn(50, 200),
            dateUpper = p.getBoolean("dateUpper", d.dateUpper),
            dateClockFont = p.getBoolean("dateClockFont", d.dateClockFont),
            dateLang = p.getInt("dateLang", d.dateLang).coerceIn(0, 3),
            posY = p.getInt("posY", d.posY).coerceIn(5, 90),
            posX = p.getInt("posX", d.posX).coerceIn(10, 90),
            depthEnabled = p.getBoolean("depthEnabled", d.depthEnabled),
            parallax = p.getInt("parallax", d.parallax).coerceIn(0, 200),
            clockDepth = p.getInt("clockDepth", d.clockDepth).coerceIn(-100, 100),
            invertTilt = p.getBoolean("invertTilt", d.invertTilt),
            smooth = p.getInt("smooth", d.smooth).coerceIn(4, 60),
            fps30 = p.getBoolean("fps30", d.fps30),
            target = p.getInt("target", d.target).coerceIn(0, 2),
            cutEngine = p.getInt("cutEngine", d.cutEngine).coerceIn(0, 2),
            edgeSoft = p.getInt("edgeSoft", d.edgeSoft).coerceIn(0, 100),
            edgeShift = p.getInt("edgeShift", d.edgeShift).coerceIn(-50, 50),
            bgDim = p.getInt("bgDim", d.bgDim).coerceIn(0, 70),
            bgSat = p.getInt("bgSat", d.bgSat).coerceIn(0, 200),
            overlayEnabled = p.getBoolean("overlayEnabled", d.overlayEnabled),
            overlayFront = p.getBoolean("overlayFront", d.overlayFront),
            overlayOpacity = p.getInt("overlayOpacity", d.overlayOpacity).coerceIn(0, 100),
            overlayScale = p.getInt("overlayScale", d.overlayScale).coerceIn(10, 200),
            overlayX = p.getInt("overlayX", d.overlayX).coerceIn(0, 100),
            overlayY = p.getInt("overlayY", d.overlayY).coerceIn(0, 100),
            overlayRotation = p.getInt("overlayRotation", d.overlayRotation).coerceIn(-180, 180),
            overlayFlip = p.getBoolean("overlayFlip", d.overlayFlip),
            overlayAutoCut = p.getBoolean("overlayAutoCut", d.overlayAutoCut)
        )
    }

    fun save(ctx: Context, s: ClockSettings) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putString("fontId", s.fontId)
            .putInt("weight", s.weight)
            .putBoolean("italic", s.italic)
            .putInt("spacing", s.spacing)
            .putInt("lineGap", s.lineGap)
            .putInt("textStyle", s.textStyle)
            .putInt("numerals", s.numerals)
            .putInt("sizePct", s.sizePct)
            .putInt("color", s.color)
            .putInt("color2", s.color2)
            .putInt("opacity", s.opacity)
            .putBoolean("shadow", s.shadow)
            .putBoolean("stacked", s.stacked)
            .putBoolean("use24h", s.use24h)
            .putBoolean("leadingZero", s.leadingZero)
            .putBoolean("showAmPm", s.showAmPm)
            .putBoolean("showDate", s.showDate)
            .putInt("datePos", s.datePos)
            .putInt("dateFormat", s.dateFormat)
            .putInt("dateSize", s.dateSize)
            .putBoolean("dateUpper", s.dateUpper)
            .putBoolean("dateClockFont", s.dateClockFont)
            .putInt("dateLang", s.dateLang)
            .putInt("posY", s.posY)
            .putInt("posX", s.posX)
            .putBoolean("depthEnabled", s.depthEnabled)
            .putInt("parallax", s.parallax)
            .putInt("clockDepth", s.clockDepth)
            .putBoolean("invertTilt", s.invertTilt)
            .putInt("smooth", s.smooth)
            .putBoolean("fps30", s.fps30)
            .putInt("target", s.target)
            .putInt("cutEngine", s.cutEngine)
            .putInt("edgeSoft", s.edgeSoft)
            .putInt("edgeShift", s.edgeShift)
            .putInt("bgDim", s.bgDim)
            .putInt("bgSat", s.bgSat)
            .putBoolean("overlayEnabled", s.overlayEnabled)
            .putBoolean("overlayFront", s.overlayFront)
            .putInt("overlayOpacity", s.overlayOpacity)
            .putInt("overlayScale", s.overlayScale)
            .putInt("overlayX", s.overlayX)
            .putInt("overlayY", s.overlayY)
            .putInt("overlayRotation", s.overlayRotation)
            .putBoolean("overlayFlip", s.overlayFlip)
            .putBoolean("overlayAutoCut", s.overlayAutoCut)
            .apply()
    }

    /** Wipes every setting (photos and imported fonts are kept). */
    fun reset(ctx: Context) {
        val p = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        val ver = p.getLong(KEY_IMG_VER, 0L)
        p.edit().clear().putLong(KEY_IMG_VER, ver).apply()
    }

    /** Tells the running wallpaper that a new photo/depth layer is on disk. */
    fun bumpImage(ctx: Context) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putLong(KEY_IMG_VER, System.currentTimeMillis())
            .apply()
    }
}

package com.depthclock.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.view.MotionEvent
import android.view.View

/** Live preview of the wallpaper. Drag a finger on it to tilt the depth effect. */
class PreviewView(ctx: Context) : View(ctx) {
    var settings = ClockSettings()
    var bg: Bitmap? = null
    var fg: Bitmap? = null
    var ov: Bitmap? = null

    private val renderer = ClockRenderer()
    private val clip = Path()
    private var px = 0f
    private var py = 0f

    override fun onDraw(canvas: Canvas) {
        val r = 28f * resources.displayMetrics.density
        clip.reset()
        clip.addRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, Path.Direction.CW)
        canvas.clipPath(clip)
        renderer.draw(canvas, width, height, settings, bg, fg, ov, px, py, System.currentTimeMillis())
        postInvalidateDelayed(30_000L)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                px = ((e.x / width) * 2f - 1f).coerceIn(-1f, 1f)
                py = ((e.y / height) * 2f - 1f).coerceIn(-1f, 1f)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                px = 0f
                py = 0f
                invalidate()
            }
        }
        return true
    }
}

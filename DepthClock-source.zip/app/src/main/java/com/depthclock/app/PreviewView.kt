package com.depthclock.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Live preview of the wallpaper.
 * - Touch the clock and drag to move it (snaps to the centre line).
 * - Touch anywhere else and drag to tilt the depth effect; it springs back on release.
 */
class PreviewView(ctx: Context) : View(ctx) {
    var settings = ClockSettings()
    var bg: Bitmap? = null
    var fg: Bitmap? = null
    var ov: Bitmap? = null
    var onClockMoved: ((Int, Int) -> Unit)? = null

    private val renderer = ClockRenderer(ctx)
    private val clip = Path()
    private var px = 0f
    private var py = 0f
    private var spring: ValueAnimator? = null

    private var dragging = false
    private var snapped = false
    private var offX = 0f
    private var offY = 0f
    private val box = RectF()
    private val boxFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x24FFFFFF }
    private val boxLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xDDFFFFFF.toInt()
        strokeWidth = ctx.resources.displayMetrics.density * 1.6f
    }
    private val guide = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xAAFFFFFF.toInt()
        strokeWidth = ctx.resources.displayMetrics.density * 1.2f
    }

    private val tick = Runnable { invalidate() }

    override fun onDraw(canvas: Canvas) {
        val d = resources.displayMetrics.density
        val r = 30f * d
        clip.reset()
        clip.addRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, Path.Direction.CW)
        canvas.clipPath(clip)
        renderer.draw(canvas, width, height, settings, bg, fg, ov, px, py, System.currentTimeMillis())
        if (dragging) {
            box.set(renderer.clockRect)
            box.inset(-8f * d, -6f * d)
            canvas.drawRoundRect(box, 12f * d, 12f * d, boxFill)
            canvas.drawRoundRect(box, 12f * d, 12f * d, boxLine)
            if (snapped) canvas.drawLine(width / 2f, 0f, width / 2f, height.toFloat(), guide)
        }
        removeCallbacks(tick)
        postDelayed(tick, 30_000L)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        spring?.cancel()
        super.onDetachedFromWindow()
    }

    private fun hitClock(x: Float, y: Float): Boolean {
        val rc = renderer.clockRect
        if (rc.isEmpty) return false
        val pad = 14f * resources.displayMetrics.density
        return x >= rc.left - pad && x <= rc.right + pad && y >= rc.top - pad && y <= rc.bottom + pad
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                spring?.cancel()
                parent?.requestDisallowInterceptTouchEvent(true)
                if (hitClock(e.x, e.y)) {
                    dragging = true
                    offX = e.x - width * settings.posX / 100f
                    offY = e.y - height * settings.posY / 100f
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    invalidate()
                } else {
                    tiltTo(e)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    var nx = (e.x - offX) / width * 100f
                    val ny = (e.y - offY) / height * 100f
                    val snap = abs(nx - 50f) < 2f
                    if (snap && !snapped) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    snapped = snap
                    if (snap) nx = 50f
                    settings.posX = nx.roundToInt().coerceIn(10, 90)
                    settings.posY = ny.roundToInt().coerceIn(5, 90)
                    onClockMoved?.invoke(settings.posX, settings.posY)
                    invalidate()
                } else {
                    tiltTo(e)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    snapped = false
                    invalidate()
                } else {
                    val fx = px
                    val fy = py
                    spring?.cancel()
                    spring = ValueAnimator.ofFloat(1f, 0f).apply {
                        duration = 650
                        interpolator = OvershootInterpolator(2.2f)
                        addUpdateListener {
                            val k = it.animatedValue as Float
                            px = fx * k
                            py = fy * k
                            invalidate()
                        }
                        start()
                    }
                }
            }
        }
        return true
    }

    private fun tiltTo(e: MotionEvent) {
        px = ((e.x / width) * 2f - 1f).coerceIn(-1f, 1f)
        py = ((e.y / height) * 2f - 1f).coerceIn(-1f, 1f)
        invalidate()
    }
}

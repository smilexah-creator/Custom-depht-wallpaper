package com.depthclock.app

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private val bgColor = Color.parseColor("#111114")
    private val cardColor = Color.parseColor("#1C1C22")
    private val mutedColor = Color.parseColor("#9A9AA5")
    private val accentColor = Color.parseColor("#4C8DFF")
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    private lateinit var settings: ClockSettings
    private lateinit var col: LinearLayout
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var pickBtn: Button
    private lateinit var overlayBtn: Button
    private lateinit var removeOverlayBtn: Button

    private val swatchViews = ArrayList<View>()
    private val swatchColors = ArrayList<Int>()

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) importImage(uri)
    }

    private val overlayPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) importOverlay(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Prefs.load(this)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bgColor)
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(28), dp(20), dp(48))
        scroll.addView(col)
        setContentView(scroll)

        col.addView(TextView(this).apply {
            text = "Depth Clock"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(TextView(this).apply {
            text = "Live wallpaper with a clock behind your subject"
            textSize = 14f
            setTextColor(mutedColor)
        })

        // Preview, same shape as the screen
        val size = realSize()
        val aspect = size.y.toFloat() / size.x.toFloat()
        val pw = (resources.displayMetrics.widthPixels * 0.62f).toInt()
        preview = PreviewView(this)
        preview.settings = settings
        preview.bg = Store.loadBg(this)
        preview.fg = Store.loadFg(this)
        preview.ov = Store.loadOverlay(this)
        col.addView(preview, LinearLayout.LayoutParams(pw, (pw * aspect).toInt()).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(20)
        })

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(mutedColor)
            gravity = Gravity.CENTER
        }
        col.addView(status, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(12) })
        updateStatus(null)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        pickBtn = button("Choose photo", false) { picker.launch("image/*") }
        val setBtn = button("Set wallpaper", true) { applyWallpaper() }
        row.addView(pickBtn, LinearLayout.LayoutParams(0, wrap, 1f).apply { rightMargin = dp(6) })
        row.addView(setBtn, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(6) })
        col.addView(row, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(16) })

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        overlayBtn = button("Add overlay (PNG)", false) { overlayPicker.launch("image/*") }
        removeOverlayBtn = button("Remove overlay", false) {
            DepthProcessor.removeOverlay(applicationContext)
            preview.ov = null
            preview.invalidate()
            updateStatus("Overlay removed.")
        }
        row2.addView(overlayBtn, LinearLayout.LayoutParams(0, wrap, 1f).apply { rightMargin = dp(6) })
        row2.addView(removeOverlayBtn, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(6) })
        col.addView(row2, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })

        // ---- Clock style
        section("Clock style")
        fontChips()
        slider("Size", 0, 100, settings.sizePct, { "$it%" }) { settings.sizePct = it }
        colorSwatches()
        val hsv = FloatArray(3)
        Color.colorToHSV(settings.color, hsv)
        slider("Custom color", 0, 360, hsv[0].toInt(), { "$it°" }) {
            settings.color = Color.HSVToColor(floatArrayOf(it.toFloat(), 0.55f, 1f))
            refreshSwatches()
        }
        slider("Opacity", 20, 100, settings.opacity, { "$it%" }) { settings.opacity = it }
        slider("Vertical position", 5, 90, settings.posY, { "$it%" }) { settings.posY = it }
        toggle("Stacked hours / minutes", settings.stacked) { settings.stacked = it }
        toggle("24-hour time", settings.use24h) { settings.use24h = it }
        toggle("Show date", settings.showDate) { settings.showDate = it }
        toggle("Text shadow", settings.shadow) { settings.shadow = it }

        // ---- Depth
        section("Depth")
        toggle("Depth effect (clock behind subject)", settings.depthEnabled) { settings.depthEnabled = it }
        slider("Tilt strength", 0, 200, settings.parallax, { "$it%" }) { settings.parallax = it }

        // ---- Overlay
        section("Overlay (transparent PNG)")
        toggle("Show overlay", settings.overlayEnabled) { settings.overlayEnabled = it }
        toggle("In front of subject (otherwise behind clock)", settings.overlayFront) { settings.overlayFront = it }
        slider("Opacity", 0, 100, settings.overlayOpacity, { "$it%" }) { settings.overlayOpacity = it }
        slider("Size", 10, 200, settings.overlayScale, { "$it%" }) { settings.overlayScale = it }
        slider("Left / right", 0, 100, settings.overlayX, { "$it%" }) { settings.overlayX = it }
        slider("Up / down", 0, 100, settings.overlayY, { "$it%" }) { settings.overlayY = it }
    }

    // ------------------------------------------------------------ actions

    private fun applyWallpaper() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        i.putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, DepthWallpaperService::class.java)
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                Toast.makeText(this, "Open Settings > Wallpaper and pick Depth Clock", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun importImage(uri: Uri) {
        pickBtn.isEnabled = false
        updateStatus("Processing photo and finding the subject...")
        val size = realSize()
        val app = applicationContext
        Thread {
            val r = DepthProcessor.process(app, uri, size.x, size.y)
            runOnUiThread {
                pickBtn.isEnabled = true
                if (r.ok) {
                    preview.bg = Store.loadBg(this)
                    preview.fg = Store.loadFg(this)
                    preview.invalidate()
                    updateStatus(r.message)
                } else {
                    updateStatus("Could not use that photo: ${r.message}")
                }
            }
        }.start()
    }

    private fun importOverlay(uri: Uri) {
        overlayBtn.isEnabled = false
        updateStatus("Adding overlay...")
        val app = applicationContext
        Thread {
            val r = DepthProcessor.importOverlay(app, uri)
            runOnUiThread {
                overlayBtn.isEnabled = true
                if (r.ok) {
                    preview.ov = Store.loadOverlay(this)
                    preview.invalidate()
                    updateStatus(r.message)
                } else {
                    updateStatus("Could not use that image: ${r.message}")
                }
            }
        }.start()
    }

    private fun changed() {
        Prefs.save(this, settings)
        preview.settings = settings
        preview.invalidate()
    }

    private fun updateStatus(msg: String?) {
        status.text = msg ?: when {
            preview.bg == null -> "Pick a photo to get started."
            preview.fg == null -> "Photo set. No depth layer (needs a person in the photo)."
            else -> "Depth layer ready. Drag on the preview to test it."
        }
    }

    @Suppress("DEPRECATION")
    private fun realSize(): Point {
        val p = Point()
        windowManager.defaultDisplay.getRealSize(p)
        return Point(minOf(p.x, p.y), maxOf(p.x, p.y))
    }

    // ------------------------------------------------------------ UI helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int, stroke: Int?): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) d.setStroke(dp(2), stroke)
        return d
    }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.background = rounded(if (primary) accentColor else cardColor, 14, null)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun section(title: String) {
        val t = TextView(this)
        t.text = title.uppercase()
        t.textSize = 12f
        t.letterSpacing = 0.1f
        t.setTextColor(mutedColor)
        t.setPadding(0, dp(28), 0, dp(8))
        col.addView(t)
    }

    private fun slider(
        label: String, lo: Int, hi: Int, value: Int,
        fmt: (Int) -> String, onChange: (Int) -> Unit
    ) {
        val title = TextView(this)
        title.setTextColor(Color.WHITE)
        title.textSize = 15f
        title.text = "$label   ${fmt(value)}"
        title.setPadding(0, dp(14), 0, 0)
        col.addView(title)

        val bar = SeekBar(this)
        bar.min = lo
        bar.max = hi
        bar.progress = value
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                title.text = "$label   ${fmt(progress)}"
                onChange(progress)
                changed()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(bar, LinearLayout.LayoutParams(match, wrap))
    }

    private fun toggle(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = label
        sw.setTextColor(Color.WHITE)
        sw.textSize = 15f
        sw.isChecked = value
        sw.setPadding(0, dp(12), 0, dp(12))
        sw.setOnCheckedChangeListener { _, checked ->
            onChange(checked)
            changed()
        }
        col.addView(sw, LinearLayout.LayoutParams(match, wrap))
    }

    private fun fontChips() {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        hs.addView(row)
        val cells = ArrayList<LinearLayout>()

        fun refresh() {
            cells.forEachIndexed { i, cell ->
                cell.background = rounded(cardColor, 14, if (i == settings.font) Color.WHITE else null)
            }
        }

        for (i in Fonts.names.indices) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dp(16), dp(10), dp(16), dp(10))
            val sample = TextView(this)
            sample.text = "10:42"
            sample.textSize = 22f
            sample.setTextColor(Color.WHITE)
            sample.typeface = Fonts.typeface(i)
            val name = TextView(this)
            name.text = Fonts.names[i]
            name.textSize = 11f
            name.setTextColor(mutedColor)
            name.gravity = Gravity.CENTER_HORIZONTAL
            cell.addView(sample)
            cell.addView(name)
            cell.setOnClickListener {
                settings.font = i
                refresh()
                changed()
            }
            cells.add(cell)
            row.addView(cell, LinearLayout.LayoutParams(wrap, wrap).apply { rightMargin = dp(8) })
        }
        refresh()
        col.addView(hs, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = dp(4) })
    }

    private fun colorSwatches() {
        val label = TextView(this)
        label.text = "Color"
        label.setTextColor(Color.WHITE)
        label.textSize = 15f
        label.setPadding(0, dp(14), 0, dp(8))
        col.addView(label)

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        hs.addView(row)

        val hexes = listOf(
            "#FFFFFF", "#FFE9A8", "#FFB454", "#FF6B6B", "#FF7EB6",
            "#C792EA", "#7AA2FF", "#5EEAD4", "#A3E635", "#111114"
        )
        for (hex in hexes) {
            val c = Color.parseColor(hex)
            val v = View(this)
            v.setOnClickListener {
                settings.color = c
                refreshSwatches()
                changed()
            }
            swatchViews.add(v)
            swatchColors.add(c)
            row.addView(v, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(10) })
        }
        refreshSwatches()
        col.addView(hs, LinearLayout.LayoutParams(match, wrap))
    }

    private fun refreshSwatches() {
        for (i in swatchViews.indices) {
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(swatchColors[i])
            val selected = swatchColors[i] == settings.color
            d.setStroke(dp(3), if (selected) accentColor else Color.parseColor("#44FFFFFF"))
            swatchViews[i].background = d
        }
    }
}

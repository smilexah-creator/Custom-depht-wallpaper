package com.depthclock.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    private lateinit var kit: Kit
    private lateinit var settings: ClockSettings
    private lateinit var aurora: AuroraView
    private lateinit var col: LinearLayout
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var pickBtn: TextView
    private lateinit var tabHolder: FrameLayout
    private lateinit var fontGrid: LinearLayout
    private lateinit var colorSwatches: Swatches
    private lateinit var color2Swatches: Swatches
    private lateinit var posXSlider: GlassSlider
    private lateinit var posYSlider: GlassSlider
    private val infoRows = ArrayList<Pair<TextView, () -> String>>()

    private val tabViews = ArrayList<LinearLayout>()
    private val fontCells = ArrayList<FontCell>()
    private val numeralChips = ArrayList<TextView>()
    private var currentTab = 0
    private var busy = false
    private var pendingRecut = false
    private var pendingFull = false
    private var pulse: ObjectAnimator? = null

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) importImage(uri)
    }
    private val overlayPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) importOverlay(uri)
    }
    private val fontPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) importFont(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.init(this)
        settings = Prefs.load(this)
        kit = Kit(this)

        // edge-to-edge, transparent system bars
        WindowCompat.setDecorFitsSystemWindows(window, false)
        @Suppress("DEPRECATION")
        window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        val root = FrameLayout(this)
        root.layoutDirection = if (Lang.isRtl()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        aurora = AuroraView(this)
        root.addView(aurora, FrameLayout.LayoutParams(match, match))

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.clipToPadding = false
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(14), dp(18), dp(40))
        scroll.addView(col, FrameLayout.LayoutParams(match, wrap))
        root.addView(scroll, FrameLayout.LayoutParams(match, match))
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        // ---- header
        col.addView(kit.text("Depth Clock", 36f, Glass.TEXT, true).apply {
            letterSpacing = -0.02f
            setPaddingRelative(dp(6), dp(8), 0, 0)
        })
        col.addView(kit.text("A clock that lives behind your subject", 15f, Glass.MUTED).apply {
            setPaddingRelative(dp(6), dp(2), 0, 0)
        })

        // ---- preview in a glass bezel, same shape as the screen
        val size = realSize()
        val aspect = size.y.toFloat() / size.x.toFloat()
        val pw = (resources.displayMetrics.widthPixels * 0.58f).toInt()
        preview = PreviewView(this)
        preview.settings = settings
        preview.bg = Store.loadBg(this)
        preview.fg = Store.loadFg(this)
        preview.ov = Store.loadOverlay(this)
        aurora.setPhoto(preview.bg)
        preview.onClockMoved = { _, _ ->
            posXSlider.assign(settings.posX)
            posYSlider.assign(settings.posY)
            Prefs.save(this, settings)
        }
        val bezel = FrameLayout(this)
        bezel.background = GlassDrawable(dpf(40f), dpf(1.4f), Color.WHITE, 0x26, 0x10)
        bezel.setPadding(dp(8), dp(8), dp(8), dp(8))
        bezel.addView(preview, FrameLayout.LayoutParams(pw, (pw * aspect).toInt()))
        col.addView(bezel, LinearLayout.LayoutParams(wrap, wrap).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(20)
        })

        status = kit.text("", 13f, Glass.MUTED).apply {
            gravity = Gravity.CENTER
            background = GlassDrawable(dpf(18f), dpf(1f), Color.WHITE, 0x1A, 0x0A)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        col.addView(status, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(16) })
        updateStatus(null)

        // ---- main actions
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        pickBtn = kit.button("Choose photo", false) {
            if (busy) busyToast() else picker.launch("image/*")
        }
        val setBtn = kit.button("Set wallpaper", true) { showTargetSheet() }
        actions.addView(pickBtn, LinearLayout.LayoutParams(0, wrap, 1f).apply { rightMargin = dp(6) })
        actions.addView(setBtn, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(6) })
        col.addView(actions, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(12) })

        // ---- tabs
        val tabs = GlassSegmented(this, listOf("Clock", "Fonts", "Depth", "Overlay", "More").map { Lang.tr(it) }, 0, 12.5f) {
            showTab(it)
        }
        col.addView(tabs, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(22) })

        tabHolder = FrameLayout(this)
        tabViews.add(buildClockTab())
        tabViews.add(buildFontsTab())
        tabViews.add(buildDepthTab())
        tabViews.add(buildOverlayTab())
        tabViews.add(buildMoreTab())
        for ((i, v) in tabViews.withIndex()) {
            v.visibility = if (i == 0) View.VISIBLE else View.GONE
            tabHolder.addView(v, FrameLayout.LayoutParams(match, wrap))
        }
        col.addView(tabHolder, LinearLayout.LayoutParams(match, wrap))

        // ---- entrance animation
        for (i in 0 until col.childCount) col.getChildAt(i).enter(80L * i, dpf(34f))
    }

    override fun onStart() {
        super.onStart()
        aurora.resume()
    }

    override fun onStop() {
        aurora.pause()
        super.onStop()
    }

    // ------------------------------------------------------------ tabs

    private fun showTab(i: Int) {
        if (i == currentTab) return
        val old = tabViews[currentTab]
        val next = tabViews[i]
        val dir = if (i > currentTab) 1 else -1
        currentTab = i
        if (i == 4) refreshInfo()
        old.animate().cancel()
        next.animate().cancel()
        old.animate().alpha(0f).translationX(-dir * dpf(26f)).setDuration(150)
            .withEndAction { if (old !== tabViews[currentTab]) old.visibility = View.GONE }
            .start()
        next.visibility = View.VISIBLE
        next.alpha = 0f
        next.translationX = dir * dpf(26f)
        next.animate().alpha(1f).translationX(0f).setStartDelay(90).setDuration(360)
            .setInterpolator(DecelerateInterpolator(2f)).start()
    }

    private fun tab(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun card(vararg rows: View): LinearLayout {
        val c = kit.card()
        rows.forEachIndexed { i, v -> kit.addTo(c, v, i == rows.lastIndex) }
        return c
    }

    private fun sw(label: String, value: Boolean, set: (Boolean) -> Unit): View =
        kit.switchRow(label, value) { set(it); changed() }

    private fun sl(
        label: String, lo: Int, hi: Int, v: Int,
        fmt: (Int) -> String = { "$it%" },
        rainbow: Boolean = false,
        onRelease: (() -> Unit)? = null,
        set: (Int) -> Unit
    ): View = kit.sliderRow(label, lo, hi, v, fmt, rainbow, { set(it); changed() }, onRelease)

    private fun seg(label: String, labels: List<String>, sel: Int, set: (Int) -> Unit): View =
        kit.segmentedRow(label, labels, sel) { set(it); changed() }

    private val textColors = listOf(
        "#FFFFFF", "#FFE9A8", "#FFB454", "#FF6B6B", "#FF7EB6",
        "#C792EA", "#7AA2FF", "#5EEAD4", "#A3E635", "#111114"
    ).map { Color.parseColor(it) }

    private fun buildClockTab(): LinearLayout {
        val t = tab()
        t.addView(kit.header("Size & position"))
        val posYRow = sl("Vertical position", 5, 90, settings.posY) { settings.posY = it }
        val posXRow = sl("Horizontal position", 10, 90, settings.posX) { settings.posX = it }
        posYSlider = posYRow.tag as GlassSlider
        posXSlider = posXRow.tag as GlassSlider
        t.addView(card(
            sl("Size", 0, 100, settings.sizePct) { settings.sizePct = it },
            posYRow,
            posXRow,
            sl("Opacity", 20, 100, settings.opacity) { settings.opacity = it }
        ))
        t.addView(kit.note(Lang.TIP_DRAG))

        t.addView(kit.header("Color"))
        colorSwatches = Swatches(this, textColors, { settings.color }) {
            settings.color = it
            changed()
        }
        color2Swatches = Swatches(this, textColors, { settings.color2 }) {
            settings.color2 = it
            changed()
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(settings.color, hsv)
        t.addView(card(
            kit.labelled("Color", colorSwatches.view),
            sl("Custom hue", 0, 360, hsv[0].toInt(), fmt = { "$it°" }, rainbow = true) {
                settings.color = Color.HSVToColor(floatArrayOf(it.toFloat(), 0.55f, 1f))
                colorSwatches.refresh()
            },
            kit.labelled("Second color (Gradient style)", color2Swatches.view),
            sw("Soft shadow", settings.shadow) { settings.shadow = it }
        ))

        t.addView(kit.header("Time"))
        t.addView(card(
            sw("Stack hours over minutes", settings.stacked) { settings.stacked = it },
            sw("24-hour time", settings.use24h) { settings.use24h = it },
            sw("Leading zero", settings.leadingZero) { settings.leadingZero = it },
            sw("Show AM / PM (12-hour)", settings.showAmPm) { settings.showAmPm = it }
        ))

        t.addView(kit.header("Date"))
        t.addView(card(
            sw("Show date", settings.showDate) { settings.showDate = it },
            seg("Position", listOf("Above", "Below"), settings.datePos) { settings.datePos = it },
            seg("Format", listOf("Full", "Short", "Day", "Weekday"), settings.dateFormat) { settings.dateFormat = it },
            sl("Date size", 50, 200, settings.dateSize) { settings.dateSize = it },
            sw("UPPERCASE", settings.dateUpper) { settings.dateUpper = it },
            sw("Use the clock's font", settings.dateClockFont) { settings.dateClockFont = it },
            seg("Date language", listOf("Device", "English", "العربية", "الدارجة"), settings.dateLang) { settings.dateLang = it }
        ))
        return t
    }

    private fun buildFontsTab(): LinearLayout {
        val t = tab()
        t.addView(kit.header("Style"))
        t.addView(card(
            seg("Text style", listOf("Solid", "Gradient", "Outline", "Glass"), settings.textStyle) {
                settings.textStyle = it
            }
        ))

        t.addView(kit.header("Fonts"))
        fontGrid = LinearLayout(this)
        fontGrid.orientation = LinearLayout.VERTICAL
        buildFontGrid()
        t.addView(fontGrid)
        t.addView(kit.button("+  Import a font file (.ttf / .otf)", false) {
            fontPicker.launch("*/*")
        }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(10) })
        t.addView(kit.note(Lang.NOTE_FONTS))

        t.addView(kit.header("Numerals"))
        t.addView(numeralChips())

        t.addView(kit.header("Fine tuning"))
        t.addView(card(
            sl("Weight (system fonts)", 0, 900, settings.weight, fmt = { if (it < 50) "Auto" else "${(it / 50) * 50}" }) {
                settings.weight = if (it < 50) 0 else (it / 50) * 50
            },
            sw("Italic", settings.italic) { settings.italic = it },
            sl("Letter spacing", -5, 30, settings.spacing, fmt = { "$it" }) { settings.spacing = it },
            sl("Line gap (stacked)", 0, 40, settings.lineGap) { settings.lineGap = it }
        ))
        return t
    }

    private fun buildFontGrid() {
        fontGrid.removeAllViews()
        fontCells.clear()
        val all = Fonts.builtIn + Fonts.imported(this)
        val groups = LinkedHashMap<String, MutableList<FontDef>>()
        for (f in all) groups.getOrPut(f.group) { ArrayList() }.add(f)
        for ((name, list) in groups) {
            fontGrid.addView(kit.text(name, 13f, Glass.MUTED, true).apply {
                setPadding(dp(8), dp(12), 0, dp(6))
            })
            var i = 0
            while (i < list.size) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                for (k in 0 until 3) {
                    val lp = LinearLayout.LayoutParams(0, wrap, 1f).apply {
                        setMargins(dp(4), dp(4), dp(4), dp(4))
                    }
                    if (i + k < list.size) {
                        row.addView(makeFontCell(list[i + k]), lp)
                    } else {
                        row.addView(View(this), lp)
                    }
                }
                fontGrid.addView(row)
                i += 3
            }
        }
        refreshFontCells()
    }

    private fun makeFontCell(def: FontDef): FontCell {
        val cell = FontCell(this, def)
        cell.numerals = settings.numerals
        cell.setOnClickListener {
            settings.fontId = def.id
            refreshFontCells()
            changed()
        }
        if (def.file != null) {
            cell.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle(Lang.trf("Remove \"%s\"?", def.label))
                    .setPositiveButton(Lang.tr("Remove")) { _, _ ->
                        def.file.delete()
                        if (settings.fontId == def.id) settings.fontId = Fonts.DEFAULT_ID
                        buildFontGrid()
                        changed()
                    }
                    .setNegativeButton(Lang.tr("Cancel"), null)
                    .show()
                true
            }
        }
        fontCells.add(cell)
        return cell
    }

    private fun refreshFontCells() {
        for (c in fontCells) {
            c.numerals = settings.numerals
            c.setPicked(c.def.id == settings.fontId)
            c.invalidate()
        }
    }

    private fun numeralChips(): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.overScrollMode = View.OVER_SCROLL_NEVER
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(2), dp(2), dp(2), dp(2))
        numeralChips.clear()
        for (i in 0 until Numerals.count) {
            val chip = kit.text(Numerals.sample(i), 20f, Glass.TEXT, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(12), dp(20), dp(12))
                isClickable = true
                setOnClickListener {
                    settings.numerals = i
                    refreshNumeralChips()
                    refreshFontCells()
                    changed()
                }
                pressEffect(0.92f)
            }
            numeralChips.add(chip)
            row.addView(chip, LinearLayout.LayoutParams(wrap, wrap).apply { rightMargin = dp(8) })
        }
        refreshNumeralChips()
        hs.addView(row)
        return hs
    }

    private fun refreshNumeralChips() {
        for (i in numeralChips.indices) {
            numeralChips[i].background =
                if (i == settings.numerals) GlassDrawable(dpf(18f), dpf(1.4f), Glass.ACCENT, 0x99, 0x55)
                else GlassDrawable(dpf(18f), dpf(1f))
        }
    }

    private fun buildDepthTab(): LinearLayout {
        val t = tab()
        t.addView(kit.header("Depth effect"))
        t.addView(card(
            sw("Clock behind subject", settings.depthEnabled) { settings.depthEnabled = it },
            sl("Tilt strength", 0, 200, settings.parallax) { settings.parallax = it },
            sl("Clock depth", -100, 100, settings.clockDepth,
                fmt = { if (it < -10) Lang.trf("Back %d", it) else if (it > 10) Lang.trf("Front +%d", it) else "Middle" }) { settings.clockDepth = it },
            sw("Invert tilt direction", settings.invertTilt) { settings.invertTilt = it }
        ))

        t.addView(kit.header("AI cut-out"))
        t.addView(card(
            kit.segmentedRow("Engine", listOf("Auto", "Any subject", "Person"), settings.cutEngine) {
                settings.cutEngine = it
                changed()
                runRecut(true)
            },
            sl("Edge softness", 0, 100, settings.edgeSoft, onRelease = { runRecut(false) }) { settings.edgeSoft = it },
            sl("Edge shift (shrink / grow)", -50, 50, settings.edgeShift,
                fmt = { if (it > 0) "+$it" else "$it" }, onRelease = { runRecut(false) }) { settings.edgeShift = it }
        ))
        t.addView(kit.button("Re-cut with AI", true) { runRecut(true) },
            LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(12) })
        t.addView(kit.note(Lang.NOTE_AI))

        t.addView(kit.header("Background"))
        t.addView(card(
            sl("Dim background (makes the subject pop)", 0, 70, settings.bgDim) { settings.bgDim = it },
            sl("Color saturation", 0, 200, settings.bgSat) { settings.bgSat = it }
        ))
        return t
    }

    private fun buildOverlayTab(): LinearLayout {
        val t = tab()
        t.addView(kit.header("Overlay image"))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(kit.button("Add overlay", true) {
            if (busy) busyToast() else overlayPicker.launch("image/*")
        }, LinearLayout.LayoutParams(0, wrap, 1f).apply { rightMargin = dp(6) })
        row.addView(kit.button("Remove", false) {
            DepthProcessor.removeOverlay(applicationContext)
            preview.ov = null
            preview.invalidate()
            updateStatus("Overlay removed.")
        }, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(6) })
        t.addView(row)
        t.addView(kit.note(Lang.NOTE_OVERLAY))

        t.addView(kit.header("Behavior"))
        t.addView(card(
            sw("Show overlay", settings.overlayEnabled) { settings.overlayEnabled = it },
            sw("In front of subject", settings.overlayFront) { settings.overlayFront = it },
            sw("AI auto-cut for opaque images", settings.overlayAutoCut) { settings.overlayAutoCut = it }
        ))

        t.addView(kit.header("Placement"))
        t.addView(card(
            sl("Opacity", 0, 100, settings.overlayOpacity) { settings.overlayOpacity = it },
            sl("Size", 10, 200, settings.overlayScale) { settings.overlayScale = it },
            sl("Left / right", 0, 100, settings.overlayX) { settings.overlayX = it },
            sl("Up / down", 0, 100, settings.overlayY) { settings.overlayY = it },
            sl("Rotation", -180, 180, settings.overlayRotation, fmt = { "$it°" }) { settings.overlayRotation = it },
            sw("Flip horizontally", settings.overlayFlip) { settings.overlayFlip = it }
        ))
        return t
    }

    private fun buildMoreTab(): LinearLayout {
        val t = tab()
        t.addView(kit.header("Language"))
        t.addView(card(
            kit.segmentedRow("App language", listOf("English", "العربية", "الدارجة"), Lang.codes.indexOf(Lang.code)) {
                Lang.set(this, Lang.codes[it])
                window.decorView.postDelayed({ recreate() }, 380)
            }
        ))

        t.addView(kit.header("Wallpaper screen"))
        t.addView(card(
            seg("Show on", listOf("Both", "Home", "Lock"), settings.target) { settings.target = it }
        ))
        t.addView(kit.note(if (Build.VERSION.SDK_INT >= 34) Lang.NOTE_TARGET_NEW else Lang.NOTE_TARGET_OLD))

        t.addView(kit.header("Motion"))
        t.addView(card(
            sl("Tilt smoothing (lower = snappier)", 4, 60, settings.smooth) { settings.smooth = it },
            seg("Frame rate", listOf("60 fps", "30 fps (saves battery)"), if (settings.fps30) 1 else 0) {
                settings.fps30 = it == 1
            }
        ))

        t.addView(kit.header("AI model"))
        t.addView(card(
            info("Person model (built in)") { "≈ 4.5 MB in the app" },
            info("Any-subject model (Google)") { "Managed by Google Play" },
            info("Last cut used") { Cutter.load(Store.alphaFile(this))?.engine ?: "none yet" }
        ))
        t.addView(kit.note(Lang.NOTE_MODEL))

        t.addView(kit.header("Storage"))
        t.addView(card(
            info("App size") { fmtSize(File(applicationInfo.sourceDir).length()) },
            info("Photos & cut-outs") { fmtSize(photoBytes()) },
            info("Imported fonts") { fmtSize(fontBytes()) }
        ))

        t.addView(kit.header("Reset"))
        t.addView(kit.button("Reset all settings", false) {
            AlertDialog.Builder(this)
                .setTitle(Lang.tr("Reset all settings?"))
                .setMessage(Lang.tr("Your photo, overlay and imported fonts are kept."))
                .setPositiveButton(Lang.tr("Reset")) { _, _ ->
                    Prefs.reset(this)
                    recreate()
                }
                .setNegativeButton(Lang.tr("Cancel"), null)
                .show()
        })

        t.addView(kit.header("About"))
        t.addView(card(
            kit.text("Depth Clock 2.0", 15.5f, Glass.TEXT, true).apply { setPadding(0, dp(14), 0, dp(2)) },
            kit.text(
                "Set it as a live wallpaper from the Set wallpaper button. All processing happens on your phone.",
                13.5f, Glass.MUTED
            ).apply { setPadding(0, dp(8), 0, dp(14)) }
        ))
        return t
    }

    // ------------------------------------------------------------ info rows

    private fun info(label: String, supplier: () -> String): View {
        val (row, tv) = kit.infoRow(label, supplier())
        infoRows.add(Pair(tv, supplier))
        return row
    }

    private fun refreshInfo() {
        for ((tv, f) in infoRows) tv.text = Lang.tr(f())
    }

    private fun fmtSize(b: Long): String =
        if (b < 1024L * 1024L) String.format(Locale.US, "%d KB", (b + 1023L) / 1024L)
        else String.format(Locale.US, "%.1f MB", b / 1048576.0)

    private fun photoBytes(): Long = listOf(
        Store.bgFile(this), Store.fgFile(this), Store.alphaFile(this), Store.overlayFile(this)
    ).sumOf { if (it.exists()) it.length() else 0L }

    private fun fontBytes(): Long =
        (Fonts.fontsDir(this).listFiles() ?: emptyArray()).sumOf { it.length() }

    // ------------------------------------------------------------ actions

    /** Bottom sheet: pick Home, Lock or both, then open Android's live wallpaper screen. */
    private fun showTargetSheet() {
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val frame = FrameLayout(this)
        frame.setPadding(dp(10), dp(10), dp(10), dp(10))
        frame.layoutDirection = if (Lang.isRtl()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(18), dp(18), dp(14))
        box.background = GlassDrawable(dpf(30f), dpf(1.2f), 0xFF14141F.toInt(), 0xF4, 0xEA)
        box.addView(kit.text("Show the wallpaper on", 18f, Glass.TEXT, true).apply {
            setPadding(dp(4), dp(2), dp(4), dp(8))
        })
        val options = listOf("Both screens" to 0, "Home screen" to 1, "Lock screen" to 2)
        for ((label, value) in options) {
            box.addView(kit.button(label, settings.target == value) {
                settings.target = value
                changed()
                dlg.dismiss()
                applyWallpaper()
            }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
        }
        box.addView(kit.note(if (Build.VERSION.SDK_INT >= 34) Lang.NOTE_TARGET_NEW else Lang.NOTE_TARGET_OLD))
        frame.addView(box, FrameLayout.LayoutParams(match, wrap))
        dlg.setContentView(frame)
        dlg.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            w.attributes = w.attributes.apply { dimAmount = 0.55f }
        }
        dlg.show()
    }

    private fun applyWallpaper() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        i.putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, DepthWallpaperService::class.java)
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                Toast.makeText(this, Lang.tr("Open Settings > Wallpaper and pick Depth Clock"), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun busyToast() {
        Toast.makeText(this, Lang.tr("Still working, one moment..."), Toast.LENGTH_SHORT).show()
    }

    private fun setBusy(on: Boolean, msg: String? = null) {
        busy = on
        pulse?.cancel()
        if (on) {
            if (msg != null) status.text = Lang.tr(msg)
            pulse = ObjectAnimator.ofFloat(status, "alpha", 1f, 0.4f).apply {
                duration = 750
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                start()
            }
        } else {
            status.alpha = 1f
        }
    }

    private fun importImage(uri: Uri) {
        if (busy) { busyToast(); return }
        setBusy(true, "Processing your photo and cutting out the subject...")
        val size = realSize()
        val app = applicationContext
        val snap = settings.copy()
        Thread {
            val r = DepthProcessor.process(app, uri, size.x, size.y, snap)
            runOnUiThread {
                setBusy(false)
                if (r.ok) {
                    preview.bg = Store.loadBg(this)
                    preview.fg = Store.loadFg(this)
                    preview.invalidate()
                    aurora.setPhoto(preview.bg)
                    updateStatus(r.message)
                } else {
                    updateStatus(Lang.trf("Could not use that photo: %s", r.message))
                }
                flushPending()
            }
        }.start()
    }

    private fun importOverlay(uri: Uri) {
        if (busy) { busyToast(); return }
        setBusy(true, "Adding your overlay...")
        val app = applicationContext
        val snap = settings.copy()
        Thread {
            val r = DepthProcessor.importOverlay(app, uri, snap)
            runOnUiThread {
                setBusy(false)
                if (r.ok) {
                    preview.ov = Store.loadOverlay(this)
                    preview.invalidate()
                    updateStatus(r.message)
                } else {
                    updateStatus(Lang.trf("Could not use that image: %s", r.message))
                }
                flushPending()
            }
        }.start()
    }

    /** Re-cuts the saved photo. full = run the AI again, otherwise only re-apply the edge settings. */
    private fun runRecut(full: Boolean) {
        if (preview.bg == null) {
            if (full) updateStatus("Choose a photo first.")
            return
        }
        if (busy) {
            pendingRecut = true
            pendingFull = pendingFull || full
            return
        }
        setBusy(true, if (full) "AI is cutting out your subject..." else "Refining the edges...")
        val app = applicationContext
        val snap = settings.copy()
        Thread {
            val r = DepthProcessor.recut(app, snap, full)
            runOnUiThread {
                setBusy(false)
                if (r.ok) {
                    preview.fg = Store.loadFg(this)
                    preview.invalidate()
                    updateStatus(r.message)
                } else {
                    updateStatus(Lang.trf("Could not re-cut: %s", r.message))
                }
                flushPending()
            }
        }.start()
    }

    private fun flushPending() {
        if (pendingRecut) {
            val f = pendingFull
            pendingRecut = false
            pendingFull = false
            runRecut(f)
        }
    }

    private fun importFont(uri: Uri) {
        val app = applicationContext
        Thread {
            var ok = false
            var name = ""
            try {
                var display: String? = null
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) display = it.getString(0)
                }
                var fileName = (display ?: "font_${System.currentTimeMillis()}")
                    .replace(Regex("[^A-Za-z0-9._ -]"), "_")
                val lower = fileName.lowercase()
                if (!lower.endsWith(".ttf") && !lower.endsWith(".otf") && !lower.endsWith(".ttc")) {
                    fileName += ".ttf"
                }
                val out = File(Fonts.fontsDir(app), fileName)
                contentResolver.openInputStream(uri)?.use { input ->
                    out.outputStream().use { input.copyTo(it) }
                }
                try {
                    Fonts.validate(out)
                    ok = true
                    name = out.name
                } catch (e: Exception) {
                    out.delete()
                }
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                if (ok) {
                    settings.fontId = "custom:$name"
                    buildFontGrid()
                    changed()
                    Toast.makeText(this, Lang.tr("Font added"), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, Lang.tr("That isn't a usable font file"), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun changed() {
        Prefs.save(this, settings)
        preview.settings = settings
        preview.invalidate()
    }

    private fun updateStatus(msg: String?) {
        status.text = Lang.tr(msg ?: when {
            preview.bg == null -> "Choose a photo to get started."
            preview.fg == null -> "Photo set. No depth layer yet. Tap Re-cut with AI in the Depth tab."
            else -> "Depth layer ready. Drag the clock to move it, or drag elsewhere to tilt."
        })
    }

    @Suppress("DEPRECATION")
    private fun realSize(): Point {
        val p = Point()
        windowManager.defaultDisplay.getRealSize(p)
        return Point(minOf(p.x, p.y), maxOf(p.x, p.y))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density
}

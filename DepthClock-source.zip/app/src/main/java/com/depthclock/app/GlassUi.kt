package com.depthclock.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

object Glass {
    const val ACCENT = 0xFF0A84FF.toInt()
    const val GREEN = 0xFF30D158.toInt()
    const val TEXT = Color.WHITE
    const val MUTED = 0x99FFFFFF.toInt()
    const val FAINT = 0x66FFFFFF
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun Context.sp(v: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

/** Springy press feedback, like iOS controls. Does not swallow clicks. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressEffect(scaleTo: Float = 0.96f) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(scaleTo).scaleY(scaleTo).setDuration(110)
                    .setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(420)
                    .setInterpolator(OvershootInterpolator(3f)).start()
        }
        false
    }
}

/** Slides a view up while fading it in. */
fun View.enter(delayMs: Long, distancePx: Float) {
    alpha = 0f
    translationY = distancePx
    animate().alpha(1f).translationY(0f).setStartDelay(delayMs).setDuration(560)
        .setInterpolator(DecelerateInterpolator(2f)).start()
}

/** Frosted glass: translucent fill, glossy top sheen and a light-catching gradient edge. */
class GlassDrawable(
    private val radius: Float,
    private val stroke: Float,
    private val tint: Int = Color.WHITE,
    private val topAlpha: Int = 0x2E,
    private val bottomAlpha: Int = 0x12
) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke }
    private val rect = RectF()

    override fun onBoundsChange(b: Rect) {
        super.onBoundsChange(b)
        val half = stroke / 2f
        rect.set(b.left + half, b.top + half, b.right - half, b.bottom - half)
        val rgb = tint and 0x00FFFFFF
        fill.shader = LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            (topAlpha shl 24) or rgb, (bottomAlpha shl 24) or rgb, Shader.TileMode.CLAMP
        )
        sheen.shader = LinearGradient(
            0f, rect.top, 0f, rect.top + rect.height() * 0.5f,
            0x2EFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP
        )
        edge.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(0xCCFFFFFF.toInt(), 0x22FFFFFF, 0x12FFFFFF, 0x77FFFFFF),
            floatArrayOf(0f, 0.38f, 0.62f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun draw(c: Canvas) {
        if (rect.isEmpty) return
        c.drawRoundRect(rect, radius, radius, fill)
        c.drawRoundRect(rect, radius, radius, sheen)
        c.drawRoundRect(rect, radius, radius, edge)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

// ---------------------------------------------------------------- slider

class GlassSlider(
    ctx: Context,
    private val lo: Int,
    private val hi: Int,
    value: Int,
    private val rainbow: Boolean = false,
    private val onChange: (Int) -> Unit,
    private val onRelease: (() -> Unit)? = null
) : View(ctx) {

    var value: Int = value.coerceIn(lo, hi)
        private set
    private var visual = this.value.toFloat()
    private var thumbScale = 1f
    private var scaleAnim: ValueAnimator? = null
    var onAssign: ((Int) -> Unit)? = null

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FFFFFF }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF2FFFFFF.toInt() }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40000000 }
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val rect = RectF()
    private val thumbR = ctx.dpf(13f)
    private val trackH = ctx.dpf(6f)
    private val pad = thumbR + ctx.dpf(3f)

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(getDefaultSize(suggestedMinimumWidth, w), context.dp(38))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (rainbow) {
            val cols = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 0.55f, 1f)) }
            trackPaint.shader = LinearGradient(pad, 0f, w - pad, 0f, cols, null, Shader.TileMode.CLAMP)
        }
    }

    fun assign(v: Int) {
        value = v.coerceIn(lo, hi)
        visual = value.toFloat()
        onAssign?.invoke(value)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val cy = height / 2f
        val left = pad
        val right = width - pad
        val span = (hi - lo).toFloat().coerceAtLeast(1f)
        val frac = ((visual - lo) / span).coerceIn(0f, 1f)
        val x = left + (right - left) * frac
        rect.set(left - trackH / 2f, cy - trackH / 2f, right + trackH / 2f, cy + trackH / 2f)
        c.drawRoundRect(rect, trackH / 2f, trackH / 2f, trackPaint)
        if (!rainbow) {
            rect.set(left - trackH / 2f, cy - trackH / 2f, x, cy + trackH / 2f)
            if (rect.width() > 0f) c.drawRoundRect(rect, trackH / 2f, trackH / 2f, fillPaint)
        }
        val r = thumbR * thumbScale
        c.drawCircle(x, cy + context.dpf(1.6f), r + context.dpf(1.2f), shadowPaint)
        c.drawCircle(x, cy, r, thumbPaint)
    }

    private fun animateScale(to: Float) {
        scaleAnim?.cancel()
        scaleAnim = ValueAnimator.ofFloat(thumbScale, to).apply {
            duration = 260
            interpolator = OvershootInterpolator(2f)
            addUpdateListener {
                thumbScale = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun setFromX(x: Float) {
        val left = pad
        val right = width - pad
        val frac = ((x - left) / (right - left)).coerceIn(0f, 1f)
        visual = lo + frac * (hi - lo)
        val v = visual.roundToInt()
        invalidate()
        if (v != value) {
            value = v
            onChange(v)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                animateScale(1.2f)
                setFromX(e.x)
            }
            MotionEvent.ACTION_MOVE -> setFromX(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animateScale(1f)
                onRelease?.invoke()
            }
        }
        return true
    }
}

// ---------------------------------------------------------------- switch

class GlassSwitch(
    ctx: Context,
    checked: Boolean,
    private val onToggle: (Boolean) -> Unit
) : View(ctx) {
    var isOn: Boolean = checked
        private set
    private var pos = if (checked) 1f else 0f
    private var anim: ValueAnimator? = null
    private val eval = ArgbEvaluator()
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40000000 }
    private val rect = RectF()

    init {
        isClickable = true
        setOnClickListener { toggle() }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(context.dp(51), context.dp(31))
    }

    private fun toggle() {
        isOn = !isOn
        val from = pos
        val to = if (isOn) 1f else 0f
        anim?.cancel()
        anim = ValueAnimator.ofFloat(from, to).apply {
            duration = 340
            interpolator = OvershootInterpolator(1.3f)
            addUpdateListener {
                pos = it.animatedValue as Float
                invalidate()
            }
            start()
        }
        onToggle(isOn)
    }

    override fun onDraw(c: Canvas) {
        val p = pos.coerceIn(0f, 1f)
        trackPaint.color = eval.evaluate(p, 0x40FFFFFF, Glass.GREEN) as Int
        val h = height.toFloat()
        rect.set(0f, 0f, width.toFloat(), h)
        c.drawRoundRect(rect, h / 2f, h / 2f, trackPaint)
        val inset = context.dpf(2f)
        val r = h / 2f - inset
        val xMin = inset + r
        val xMax = width - inset - r
        val x = xMin + (xMax - xMin) * pos.coerceIn(-0.05f, 1.05f)
        c.drawCircle(x, h / 2f + context.dpf(1.2f), r + context.dpf(0.8f), shadowPaint)
        c.drawCircle(x, h / 2f, r, thumbPaint)
    }
}

// ---------------------------------------------------------------- segmented control

class GlassSegmented(
    ctx: Context,
    private val labels: List<String>,
    selected: Int,
    textSp: Float = 13f,
    private val onSelect: (Int) -> Unit
) : View(ctx) {
    var selectedIndex: Int = selected.coerceIn(0, labels.size - 1)
        private set
    private var pos = selectedIndex.toFloat()
    private var anim: ValueAnimator? = null
    private val eval = ArgbEvaluator()
    private val pad = ctx.dpf(3f)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dpf(1f) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = ctx.sp(textSp)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()

    init {
        background = GlassDrawable(ctx.dpf(18f), ctx.dpf(1f), Color.WHITE, 0x1C, 0x0C)
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(getDefaultSize(suggestedMinimumWidth, w), context.dp(38))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fill.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0x66FFFFFF, 0x33FFFFFF, Shader.TileMode.CLAMP)
        edge.color = 0x66FFFFFF
    }

    override fun onDraw(c: Canvas) {
        val n = labels.size
        val segW = (width - 2 * pad) / n
        val ih = height - 2 * pad
        val left = (pad + pos * segW).coerceIn(pad, width - pad - segW)
        rect.set(left, pad, left + segW, pad + ih)
        c.drawRoundRect(rect, ih / 2f, ih / 2f, fill)
        c.drawRoundRect(rect, ih / 2f, ih / 2f, edge)
        val fm = text.fontMetrics
        val baseline = height / 2f - (fm.ascent + fm.descent) / 2f
        for (i in 0 until n) {
            val sel = (1f - min(1f, abs(pos - i))).coerceIn(0f, 1f)
            text.color = eval.evaluate(sel, 0xB3FFFFFF.toInt(), Color.WHITE) as Int
            c.drawText(labels[i], pad + segW * (i + 0.5f), baseline, text)
        }
    }

    fun select(i: Int, notify: Boolean = true) {
        val idx = i.coerceIn(0, labels.size - 1)
        if (idx == selectedIndex) return
        selectedIndex = idx
        anim?.cancel()
        anim = ValueAnimator.ofFloat(pos, idx.toFloat()).apply {
            duration = 380
            interpolator = OvershootInterpolator(1.15f)
            addUpdateListener {
                pos = it.animatedValue as Float
                invalidate()
            }
            start()
        }
        if (notify) onSelect(idx)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_UP -> {
                val segW = (width - 2 * pad) / labels.size
                select(((e.x - pad) / segW).toInt())
                performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}

// ---------------------------------------------------------------- swatches

class SwatchView(ctx: Context, private val color: Int) : View(ctx) {
    var picked = false
        set(v) {
            if (field != v) {
                field = v
                animate().scaleX(if (v) 1.14f else 1f).scaleY(if (v) 1.14f else 1f)
                    .setDuration(300).setInterpolator(OvershootInterpolator(3f)).start()
                invalidate()
            }
        }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = this@SwatchView.color }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x55FFFFFF }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy)
        val sw = context.dpf(2.5f)
        if (picked) {
            ring.strokeWidth = sw
            ring.color = Color.WHITE
            c.drawCircle(cx, cy, r - sw / 2f, ring)
            c.drawCircle(cx, cy, r - sw - context.dpf(3f), fill)
        } else {
            c.drawCircle(cx, cy, r - context.dpf(3f), fill)
            edge.strokeWidth = context.dpf(1f)
            c.drawCircle(cx, cy, r - context.dpf(3f), edge)
        }
    }
}

class Swatches(
    private val ctx: Context,
    private val colors: List<Int>,
    private val get: () -> Int,
    private val set: (Int) -> Unit
) {
    private val views = ArrayList<SwatchView>()
    val view: HorizontalScrollView = HorizontalScrollView(ctx).apply {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, ctx.dp(4), 0, ctx.dp(4))
        for (col in colors) {
            val v = SwatchView(ctx, col)
            v.setOnClickListener {
                set(col)
                refresh()
            }
            v.pressEffect(0.88f)
            views.add(v)
            row.addView(v, LinearLayout.LayoutParams(ctx.dp(40), ctx.dp(40)).apply { rightMargin = ctx.dp(6) })
        }
        addView(row)
    }

    fun refresh() {
        val cur = get()
        for (i in views.indices) views[i].picked = (colors[i] == cur)
    }

    init {
        refresh()
    }
}

// ---------------------------------------------------------------- font cell

class FontCell(ctx: Context, val def: FontDef) : View(ctx) {
    var numerals = 0
    private var picked = false
    private val sample = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val name = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Glass.MUTED
        textSize = ctx.sp(10.5f)
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    init {
        background = glassFor(false)
        pressEffect(0.94f)
    }

    private fun glassFor(on: Boolean): GlassDrawable =
        if (on) GlassDrawable(context.dpf(18f), context.dpf(1.4f), Glass.ACCENT, 0x99, 0x55)
        else GlassDrawable(context.dpf(18f), context.dpf(1f))

    fun setPicked(on: Boolean) {
        if (picked == on) return
        picked = on
        background = glassFor(on)
        name.color = if (on) Color.WHITE else Glass.MUTED
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(getDefaultSize(suggestedMinimumWidth, w), context.dp(82))
    }

    override fun onDraw(c: Canvas) {
        sample.typeface = Fonts.typeface(def, 0, false)
        val size = context.sp(25f)
        sample.textSize = size
        val round = size * def.rounded
        if (round > 0f) {
            sample.style = Paint.Style.FILL_AND_STROKE
            sample.strokeWidth = round
        } else {
            sample.style = Paint.Style.FILL
            sample.strokeWidth = 0f
        }
        c.drawText(Numerals.convert("10:42", numerals), width / 2f, height * 0.50f, sample)
        c.drawText(def.label, width / 2f, height - context.dpf(13f), name)
    }
}

// ---------------------------------------------------------------- aurora backdrop

class AuroraView(ctx: Context) : View(ctx) {
    private class Blob(
        val bx: Float, val by: Float, val radius: Float, val color: Int,
        val speed: Float, val offset: Float
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    }

    private val blobs = listOf(
        Blob(0.15f, 0.12f, 0.80f, 0xFF0A84FF.toInt(), 1f, 0f),
        Blob(0.90f, 0.30f, 0.75f, 0xFFBF5AF2.toInt(), 1f, 2.1f),
        Blob(0.20f, 0.62f, 0.85f, 0xFF30D5C8.toInt(), 2f, 4.0f),
        Blob(0.85f, 0.90f, 0.80f, 0xFFFF375F.toInt(), 1f, 5.3f)
    )
    private val basePaint = Paint()
    private val scrim = Paint().apply { color = 0x99070710.toInt() }
    private val photoPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private var photo: Bitmap? = null
    private var phase = 0f
    private val dst = RectF()
    private val animator = ValueAnimator.ofFloat(0f, (Math.PI * 2).toFloat()).apply {
        duration = 50_000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    fun setPhoto(bmp: Bitmap?) {
        photo = bmp?.let { tiny(it) }
        invalidate()
    }

    private fun tiny(src: Bitmap): Bitmap {
        var cur = src
        while (cur.width / 2 > 48) {
            val next = Bitmap.createScaledBitmap(cur, cur.width / 2, max(2, cur.height / 2), true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        val th = max(2, (24f * cur.height / cur.width).toInt())
        val out = Bitmap.createScaledBitmap(cur, 24, th, true)
        if (cur !== src) cur.recycle()
        return out
    }

    fun resume() {
        if (!animator.isStarted) animator.start()
    }

    fun pause() {
        animator.cancel()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        basePaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(), 0xFF05050B.toInt(), 0xFF120C20.toInt(), Shader.TileMode.CLAMP
        )
        val m = max(w, h).toFloat()
        for (b in blobs) {
            val r = m * b.radius * 0.5f
            val c0 = (b.color and 0x00FFFFFF) or (0xA0 shl 24)
            val c1 = b.color and 0x00FFFFFF
            b.paint.shader = RadialGradient(0f, 0f, r, c0, c1, Shader.TileMode.CLAMP)
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, basePaint)
        val p = photo
        if (p != null) {
            val s = max(w / p.width, h / p.height)
            val dw = p.width * s
            val dh = p.height * s
            dst.set((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f)
            c.drawBitmap(p, null, dst, photoPaint)
            c.drawRect(0f, 0f, w, h, scrim)
        }
        val m = max(w, h)
        for (b in blobs) {
            val cx = w * b.bx + m * 0.08f * sin(phase * b.speed + b.offset)
            val cy = h * b.by + m * 0.06f * cos(phase * b.speed * 1.3f + b.offset)
            b.paint.alpha = if (p != null) 120 else 255
            c.save()
            c.translate(cx, cy)
            c.drawCircle(0f, 0f, m * b.radius * 0.5f, b.paint)
            c.restore()
        }
    }
}

// ---------------------------------------------------------------- builder helpers

/** Small factory for the glass building blocks used by the settings screen. */
class Kit(val ctx: Context) {
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    fun text(s: String, sizeSp: Float, color: Int = Glass.TEXT, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = Lang.tr(s)
            textSize = sizeSp
            setTextColor(color)
            typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        }

    fun header(s: String): TextView = text(s.uppercase(), 12f, Glass.MUTED, true).apply {
        letterSpacing = if (Lang.isRtl()) 0f else 0.08f
        setPadding(ctx.dp(8), ctx.dp(22), ctx.dp(8), ctx.dp(8))
    }

    fun card(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = GlassDrawable(ctx.dpf(24f), ctx.dpf(1.1f))
        setPadding(ctx.dp(18), ctx.dp(6), ctx.dp(18), ctx.dp(6))
    }

    fun note(s: String): TextView = text(s, 12.5f, Glass.MUTED).apply {
        setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), 0)
    }

    fun divider(): View = View(ctx).apply { setBackgroundColor(0x1FFFFFFF) }

    fun addTo(card: LinearLayout, v: View, last: Boolean = false) {
        card.addView(v)
        if (!last) card.addView(divider(), LinearLayout.LayoutParams(match, 1))
    }

    fun switchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, ctx.dp(10), 0, ctx.dp(10))
        row.minimumHeight = ctx.dp(52)
        val t = text(label, 15.5f)
        row.addView(t, LinearLayout.LayoutParams(0, wrap, 1f).apply { rightMargin = ctx.dp(12) })
        row.addView(GlassSwitch(ctx, value, onChange))
        return row
    }

    fun sliderRow(
        label: String, lo: Int, hi: Int, value: Int, fmt: (Int) -> String,
        rainbow: Boolean = false, onChange: (Int) -> Unit, onRelease: (() -> Unit)? = null
    ): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, ctx.dp(12), 0, ctx.dp(4))
        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        val title = text(label, 15.5f)
        val valueText = text(fmt(value), 14f, Glass.MUTED)
        top.addView(title, LinearLayout.LayoutParams(0, wrap, 1f))
        top.addView(valueText)
        box.addView(top)
        val slider = GlassSlider(ctx, lo, hi, value, rainbow, { v ->
            valueText.text = Lang.tr(fmt(v))
            onChange(v)
        }, onRelease)
        slider.onAssign = { valueText.text = Lang.tr(fmt(it)) }
        box.tag = slider
        box.addView(slider, LinearLayout.LayoutParams(match, wrap))
        return box
    }

    fun segmentedRow(label: String, labels: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, ctx.dp(12), 0, ctx.dp(12))
        box.addView(text(label, 15.5f))
        box.addView(
            GlassSegmented(ctx, labels.map { Lang.tr(it) }, selected, 12.5f, onSelect),
            LinearLayout.LayoutParams(match, wrap).apply { topMargin = ctx.dp(10) }
        )
        return box
    }

    fun infoRow(label: String, value: String): Pair<View, TextView> {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, ctx.dp(13), 0, ctx.dp(13))
        val v = text(value, 14f, Glass.MUTED)
        row.addView(text(label, 15.5f), LinearLayout.LayoutParams(0, wrap, 1f).apply { marginEnd = ctx.dp(12) })
        row.addView(v)
        return Pair(row, v)
    }

    fun labelled(label: String, content: View): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, ctx.dp(12), 0, ctx.dp(10))
        box.addView(text(label, 15.5f))
        box.addView(content, LinearLayout.LayoutParams(match, wrap).apply { topMargin = ctx.dp(8) })
        return box
    }

    fun button(label: String, primary: Boolean, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = Lang.tr(label)
        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        minimumHeight = ctx.dp(50)
        setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        background = if (primary) GlassDrawable(ctx.dpf(18f), ctx.dpf(1.2f), Glass.ACCENT, 0xF0, 0xB4)
        else GlassDrawable(ctx.dpf(18f), ctx.dpf(1.1f))
        isClickable = true
        setOnClickListener { onClick() }
        pressEffect(0.95f)
    }
}

package com.depthclock.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.atan2
import kotlin.math.hypot

class DepthWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = DepthEngine()

    private inner class DepthEngine : Engine(), SensorEventListener,
        SharedPreferences.OnSharedPreferenceChangeListener {

        private val renderer = ClockRenderer()
        private val handler = Handler(Looper.getMainLooper())
        private val prefs = getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        private val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        private var settings = ClockSettings()
        private var bg: Bitmap? = null
        private var fg: Bitmap? = null
        private var ov: Bitmap? = null
        private var loadedVer = -1L
        private var visible = false
        private var sensing = false

        // tilt state
        private var gx = 0f
        private var gy = 0f
        private var gz = 0f
        private var haveFilter = false
        private var basePitch = 0f
        private var haveBase = false
        private var px = 0f
        private var py = 0f
        private var lastDraw = 0L

        private val tick = object : Runnable {
            override fun run() {
                drawFrame()
                scheduleTick()
            }
        }

        private val reloadAndDraw = Runnable {
            reload()
            drawFrame()
        }

        override fun onCreate(surfaceHolder: SurfaceHolder?) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(false)
            prefs.registerOnSharedPreferenceChangeListener(this)
            reload()
        }

        override fun onDestroy() {
            handler.removeCallbacks(tick)
            handler.removeCallbacks(reloadAndDraw)
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            if (sensing) {
                sm.unregisterListener(this)
                sensing = false
            }
            bg = null
            fg = null
            ov = null
            super.onDestroy()
        }

        override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
            handler.removeCallbacks(reloadAndDraw)
            handler.post(reloadAndDraw)
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                reload()
                drawFrame()
                scheduleTick()
            } else {
                handler.removeCallbacks(tick)
                updateSensors()
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            visible = false
            handler.removeCallbacks(tick)
            updateSensors()
            super.onSurfaceDestroyed(holder)
        }

        private fun reload() {
            val ctx = this@DepthWallpaperService
            settings = Prefs.load(ctx)
            val ver = prefs.getLong(Prefs.KEY_IMG_VER, 0L)
            if (ver != loadedVer) {
                bg = Store.loadBg(ctx)
                fg = Store.loadFg(ctx)
                ov = Store.loadOverlay(ctx)
                loadedVer = ver
            }
            updateSensors()
        }

        private fun updateSensors() {
            val want = visible && settings.parallax > 0
            if (want && !sensing) {
                val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                if (sensor != null) {
                    sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
                    sensing = true
                    haveFilter = false
                    haveBase = false
                }
            } else if (!want && sensing) {
                sm.unregisterListener(this)
                sensing = false
                px = 0f
                py = 0f
            }
        }

        override fun onSensorChanged(event: SensorEvent?) {
            val v = event?.values ?: return
            if (!haveFilter) {
                gx = v[0]; gy = v[1]; gz = v[2]
                haveFilter = true
            } else {
                gx += 0.15f * (v[0] - gx)
                gy += 0.15f * (v[1] - gy)
                gz += 0.15f * (v[2] - gz)
            }
            val roll = atan2(gx, hypot(gy, gz))   // left / right tilt
            val pitch = atan2(gz, gy)             // forward / back tilt
            if (!haveBase) {
                basePitch = pitch
                haveBase = true
            } else {
                // neutral pose slowly follows how you hold the phone
                basePitch += 0.004f * (pitch - basePitch)
            }
            px = (roll / 0.35f).coerceIn(-1f, 1f)
            py = ((pitch - basePitch) / 0.35f).coerceIn(-1f, 1f)

            val now = SystemClock.uptimeMillis()
            if (now - lastDraw >= 16) {
                lastDraw = now
                drawFrame()
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

        private fun scheduleTick() {
            handler.removeCallbacks(tick)
            if (!visible) return
            val now = System.currentTimeMillis()
            handler.postDelayed(tick, 60_000L - now % 60_000L + 30L)
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = try {
                    holder.lockHardwareCanvas()
                } catch (e: Exception) {
                    holder.lockCanvas()
                }
                if (c != null) {
                    renderer.draw(c, c.width, c.height, settings, bg, fg, ov, px, py, System.currentTimeMillis())
                }
            } catch (e: Exception) {
                // surface not ready; next frame will try again
            } finally {
                if (c != null) {
                    try {
                        holder.unlockCanvasAndPost(c)
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }
}

package com.depthclock.app

import android.content.Context
import android.graphics.Typeface
import java.io.File

/**
 * One selectable clock font.
 * [rounded] fakes a rounded cut by stroking the glyphs with round joins (fraction of text size).
 */
data class FontDef(
    val id: String,
    val label: String,
    val group: String,
    val family: String,
    val weight: Int,
    val italic: Boolean = false,
    val rounded: Float = 0f,
    val file: File? = null
)

object Fonts {
    const val DEFAULT_ID = "sans_light"
    private const val SANS = "sans-serif"

    val builtIn: List<FontDef> = listOf(
        // Sans (system sans, every static weight)
        FontDef("sans_thin", "Thin", "Sans", SANS, 100),
        FontDef("sans_light", "Light", "Sans", SANS, 300),
        FontDef("sans_regular", "Regular", "Sans", SANS, 400),
        FontDef("sans_medium", "Medium", "Sans", SANS, 500),
        FontDef("sans_bold", "Bold", "Sans", SANS, 700),
        FontDef("sans_black", "Black", "Sans", SANS, 900),
        // Rounded (sans + round-joined stroke)
        FontDef("round_light", "Rounded Light", "Rounded", SANS, 300, rounded = 0.012f),
        FontDef("round_regular", "Rounded", "Rounded", SANS, 400, rounded = 0.018f),
        FontDef("round_semi", "Rounded Semi", "Rounded", SANS, 500, rounded = 0.026f),
        FontDef("round_bold", "Rounded Bold", "Rounded", SANS, 700, rounded = 0.030f),
        FontDef("round_heavy", "Rounded Heavy", "Rounded", SANS, 900, rounded = 0.034f),
        // Serif
        FontDef("serif_regular", "Serif", "Serif", "serif", 400),
        FontDef("serif_italic", "Serif Italic", "Serif", "serif", 400, italic = true),
        FontDef("serif_bold", "Serif Bold", "Serif", "serif", 700),
        FontDef("serif_black", "Serif Black", "Serif", "serif", 900, rounded = 0.006f),
        // Condensed
        FontDef("cond_light", "Condensed Light", "Condensed", "sans-serif-condensed", 300),
        FontDef("cond_regular", "Condensed", "Condensed", "sans-serif-condensed", 400),
        FontDef("cond_medium", "Condensed Medium", "Condensed", "sans-serif-condensed", 500),
        FontDef("cond_bold", "Condensed Bold", "Condensed", "sans-serif-condensed", 700),
        FontDef("cond_black", "Condensed Black", "Condensed", "sans-serif-condensed", 900, rounded = 0.008f),
        // Mono
        FontDef("mono_regular", "Mono", "Mono", "monospace", 400),
        FontDef("mono_bold", "Mono Bold", "Mono", "monospace", 700),
        FontDef("mono_slab", "Slab Mono", "Mono", "serif-monospace", 400),
        // Fun
        FontDef("casual", "Casual", "Fun", "casual", 400),
        FontDef("cursive", "Cursive", "Fun", "cursive", 400),
        FontDef("smallcaps", "Small Caps", "Fun", "sans-serif-smallcaps", 400)
    )

    private val byId: Map<String, FontDef> = builtIn.associateBy { it.id }
    private val cache = HashMap<String, Typeface>()
    private val customCache = HashMap<String, FontDef>()

    fun fontsDir(ctx: Context) = File(ctx.filesDir, "fonts").apply { mkdirs() }

    /** Fonts the user imported from .ttf / .otf files. */
    fun imported(ctx: Context): List<FontDef> =
        (fontsDir(ctx).listFiles() ?: emptyArray())
            .filter { it.isFile }
            .sortedBy { it.name.lowercase() }
            .map { customDef(it) }

    private fun customDef(f: File): FontDef = FontDef(
        id = "custom:" + f.name,
        label = f.nameWithoutExtension.take(18),
        group = "Imported",
        family = SANS,
        weight = 400,
        file = f
    )

    fun resolve(ctx: Context, id: String): FontDef {
        byId[id]?.let { return it }
        if (id.startsWith("custom:")) {
            synchronized(customCache) {
                customCache[id]?.let { if (it.file?.exists() == true) return it }
                val f = File(fontsDir(ctx), id.removePrefix("custom:"))
                if (f.exists()) {
                    val d = customDef(f)
                    customCache[id] = d
                    return d
                }
            }
        }
        return byId.getValue(DEFAULT_ID)
    }

    @Synchronized
    fun typeface(def: FontDef, weightOverride: Int, italicOverride: Boolean): Typeface {
        val italic = def.italic || italicOverride
        val file = def.file
        if (file != null) {
            val key = "${def.id}|$italic"
            return cache.getOrPut(key) {
                val base = try {
                    Typeface.createFromFile(file)
                } catch (e: Exception) {
                    Typeface.DEFAULT
                }
                if (italic) Typeface.create(base, Typeface.ITALIC) else base
            }
        }
        val w = if (weightOverride > 0) weightOverride else def.weight
        val key = "${def.id}|$w|$italic"
        return cache.getOrPut(key) {
            val base = Typeface.create(def.family, Typeface.NORMAL)
            Typeface.create(base, w, italic)
        }
    }

    /** Validates a font file by loading it. Throws if it is not a usable font. */
    fun validate(f: File) {
        Typeface.Builder(f).build() ?: throw IllegalArgumentException("Not a usable font file")
    }
}

/** Number systems, like the numeral choices of the iPhone lock screen. */
object Numerals {
    private val zeros = intArrayOf(
        '0'.code, 0x0660, 0x06F0, 0x0966, 0x09E6, 0x0E50, 0x0BE6, 0x0AE6
    )
    val count: Int get() = zeros.size

    fun convert(s: String, system: Int): String {
        if (system <= 0 || system >= zeros.size) return s
        val sb = StringBuilder(s.length)
        for (ch in s) {
            if (ch in '0'..'9') sb.appendCodePoint(zeros[system] + (ch - '0')) else sb.append(ch)
        }
        return sb.toString()
    }

    fun sample(system: Int): String = convert("123", system)
}

package com.depthclock.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.format.DateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Draws the layers, back to front:
 *   1. background photo (optionally dimmed / desaturated)
 *   2. overlay (unless set to "in front")
 *   3. the clock
 *   4. the cut-out subject (so the clock appears BEHIND it)
 *   5. overlay (if set to "in front")
 * px/py in [-1, 1] move the layers in opposite directions to fake depth.
 */
class ClockRenderer(private val ctx: Context) {
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val ovPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val dimPaint = Paint()
    private val fallbackPaint = Paint()
    private val dst = RectF()
    private val bounds = Rect()
    private var fallbackH = -1
    private var satValue = -1
    private var satFilter: ColorMatrixColorFilter? = null

    /** Where the clock (time + date) was drawn last, in view pixels. Used for drag-to-move. */
    val clockRect = RectF()

    fun draw(
        c: Canvas, w: Int, h: Int, s: ClockSettings,
        bg: Bitmap?, fg: Bitmap?, ov: Bitmap?, px0: Float, py0: Float, now: Long,
        plain: Boolean = false
    ) {
        if (w <= 0 || h <= 0) return
        val wf = w.toFloat()
        val hf = h.toFloat()
        val dir = if (s.invertTilt) -1f else 1f
        val px = px0 * dir
        val py = py0 * dir
        val strength = s.parallax / 100f
        val amp = wf * 0.03f * strength
        val scale = 1f + amp / wf        // enough overscan so edges never show
        val maxShift = amp * 0.5f
        val sx = px * maxShift
        val sy = py * maxShift

        if (plain) {
            // this screen is switched off in the settings: show just the photo
            bitmapPaint.colorFilter = null
            if (bg != null) layer(c, bg, wf, hf, 1f, 0f, 0f) else drawFallback(c, wf, hf)
            return
        }
        updateSaturation(s.bgSat)
        bitmapPaint.colorFilter = satFilter

        if (bg != null) {
            layer(c, bg, wf, hf, scale, -sx, -sy)
        } else {
            drawFallback(c, wf, hf)
        }
        if (s.bgDim > 0) {
            dimPaint.color = Color.argb((255 * s.bgDim / 100f).toInt().coerceIn(0, 255), 0, 0, 0)
            c.drawRect(0f, 0f, wf, hf, dimPaint)
        }
        // transparent overlay sitting just above the photo (behind the clock)
        if (ov != null && s.overlayEnabled && !s.overlayFront) {
            drawOverlay(c, ov, wf, hf, s, scale, -sx * 0.5f, -sy * 0.5f)
        }
        val cd = s.clockDepth / 100f
        c.save()
        c.translate(sx * cd, sy * cd)
        drawClock(c, wf, hf, s, now)
        c.restore()
        if (fg != null && s.depthEnabled) {
            layer(c, fg, wf, hf, scale, sx, sy)
        }
        // or in front of everything, including the subject
        if (ov != null && s.overlayEnabled && s.overlayFront) {
            drawOverlay(c, ov, wf, hf, s, scale, sx, sy)
        }
    }

    private fun updateSaturation(v: Int) {
        if (v == satValue) return
        satValue = v
        satFilter = if (v == 100) null else ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(v / 100f) })
    }

    private fun drawOverlay(
        c: Canvas, ov: Bitmap, w: Float, h: Float, s: ClockSettings,
        scale: Float, dx: Float, dy: Float
    ) {
        val fit = minOf(w / ov.width, h / ov.height) * (s.overlayScale / 100f)
        val ow = ov.width * fit
        val oh = ov.height * fit
        val cx = w * s.overlayX / 100f
        val cy = h * s.overlayY / 100f
        ovPaint.alpha = (255 * s.overlayOpacity / 100f).toInt().coerceIn(0, 255)
        c.save()
        c.translate(dx, dy)
        c.scale(scale, scale, w / 2f, h / 2f)
        if (s.overlayRotation != 0) c.rotate(s.overlayRotation.toFloat(), cx, cy)
        if (s.overlayFlip) c.scale(-1f, 1f, cx, cy)
        dst.set(cx - ow / 2f, cy - oh / 2f, cx + ow / 2f, cy + oh / 2f)
        c.drawBitmap(ov, null, dst, ovPaint)
        c.restore()
    }

    private fun layer(c: Canvas, bmp: Bitmap, w: Float, h: Float, scale: Float, dx: Float, dy: Float) {
        c.save()
        c.translate(dx, dy)
        c.scale(scale, scale, w / 2f, h / 2f)
        dst.set(0f, 0f, w, h)
        c.drawBitmap(bmp, null, dst, bitmapPaint)
        c.restore()
    }

    private fun drawFallback(c: Canvas, w: Float, h: Float) {
        if (fallbackH != h.toInt()) {
            fallbackH = h.toInt()
            fallbackPaint.shader = LinearGradient(
                0f, 0f, 0f, h,
                intArrayOf(0xFF141E30.toInt(), 0xFF35577D.toInt(), 0xFF6B7B8C.toInt()),
                null, Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, w, h, fallbackPaint)
    }

    // ------------------------------------------------------------ clock

    private fun resetPaint(p: Paint) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.strokeWidth = 0f
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
    }

    /** Draws one line of the clock in the chosen text style. */
    private fun drawStyled(
        c: Canvas, text: String, x: Float, y: Float, size: Float, s: ClockSettings,
        def: FontDef, alpha: Int, gTop: Float, gBottom: Float
    ) {
        val p = timePaint
        val round = size * def.rounded
        resetPaint(p)
        p.textSize = size
        p.alpha = 255
        when (s.textStyle) {
            1 -> { // gradient
                p.shader = LinearGradient(0f, gTop, 0f, gBottom, s.color, s.color2, Shader.TileMode.CLAMP)
                p.color = Color.WHITE
                p.alpha = alpha
                if (round > 0f) { p.style = Paint.Style.FILL_AND_STROKE; p.strokeWidth = round }
                shadow(p, size, s.shadow)
                c.drawText(text, x, y, p)
            }
            2 -> { // outline
                p.style = Paint.Style.STROKE
                p.strokeWidth = maxOf(size * 0.018f, 2f) + round
                p.color = s.color
                p.alpha = alpha
                shadow(p, size, s.shadow)
                c.drawText(text, x, y, p)
            }
            3 -> { // glass: frosted fill + bright edge
                val hi = (s.color and 0x00FFFFFF) or (0x78 shl 24)
                val lo = (s.color and 0x00FFFFFF) or (0x22 shl 24)
                p.shader = LinearGradient(0f, gTop, 0f, gBottom, hi, lo, Shader.TileMode.CLAMP)
                p.color = Color.WHITE
                p.alpha = alpha
                if (round > 0f) { p.style = Paint.Style.FILL_AND_STROKE; p.strokeWidth = round }
                shadow(p, size, s.shadow)
                c.drawText(text, x, y, p)
                resetPaint(p)
                p.textSize = size
                p.clearShadowLayer()
                p.style = Paint.Style.STROKE
                p.strokeWidth = maxOf(size * 0.010f, 1.5f) + round
                p.shader = LinearGradient(
                    0f, gTop, 0f, gBottom, 0xEEFFFFFF.toInt(), 0x44FFFFFF, Shader.TileMode.CLAMP
                )
                p.color = Color.WHITE
                p.alpha = alpha
                c.drawText(text, x, y, p)
            }
            else -> { // solid
                p.color = s.color
                p.alpha = alpha
                if (round > 0f) { p.style = Paint.Style.FILL_AND_STROKE; p.strokeWidth = round }
                shadow(p, size, s.shadow)
                c.drawText(text, x, y, p)
            }
        }
        p.clearShadowLayer()
        p.shader = null
    }

    private fun shadow(p: Paint, size: Float, on: Boolean) {
        if (on) p.setShadowLayer(size * 0.10f, 0f, size * 0.04f, 0x66000000) else p.clearShadowLayer()
    }

    private fun drawClock(c: Canvas, w: Float, h: Float, s: ClockSettings, now: Long) {
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        val hourVal = if (s.use24h) cal.get(Calendar.HOUR_OF_DAY) else cal.get(Calendar.HOUR).let { if (it == 0) 12 else it }
        val hourRaw = if (s.leadingZero) String.format(Locale.US, "%02d", hourVal) else hourVal.toString()
        val minRaw = String.format(Locale.US, "%02d", cal.get(Calendar.MINUTE))
        val hour = Numerals.convert(hourRaw, s.numerals)
        val min = Numerals.convert(minRaw, s.numerals)
        val base = s.sizePct / 100f
        val alpha = (255 * s.opacity / 100f).toInt().coerceIn(0, 255)

        val def = Fonts.resolve(ctx, s.fontId)
        val tf = Fonts.typeface(def, s.weight, s.italic)
        timePaint.typeface = tf
        timePaint.letterSpacing = s.spacing / 100f

        var ts = if (s.stacked) w * (0.20f + 0.50f * base) else w * (0.12f + 0.30f * base)
        resetPaint(timePaint)
        timePaint.textSize = ts
        val oneLine = "$hour:$min"
        val widest = if (s.stacked) {
            maxOf(timePaint.measureText(hour), timePaint.measureText(min))
        } else {
            timePaint.measureText(oneLine)
        }
        val cx = w * s.posX / 100f
        val maxW = minOf(w * 0.92f, 2f * minOf(cx, w - cx) * 0.96f)
        if (widest > maxW && widest > 0f) {
            ts *= maxW / widest
            timePaint.textSize = ts
        }

        // digit height measured on all ten digits so the layout never jumps between minutes
        timePaint.getTextBounds(Numerals.convert("0123456789", s.numerals), 0, 10, bounds)
        val dh = bounds.height().toFloat()
        val cy = h * s.posY / 100f
        val top: Float
        val blockH: Float

        if (s.stacked) {
            val gap = dh * s.lineGap / 100f
            blockH = dh * 2f + gap
            top = cy - blockH / 2f
            drawStyled(c, hour, cx, top + dh, ts, s, def, alpha, top, top + blockH)
            drawStyled(c, min, cx, top + dh * 2f + gap, ts, s, def, alpha, top, top + blockH)
        } else {
            blockH = dh
            top = cy - dh / 2f
            drawStyled(c, oneLine, cx, top + dh, ts, s, def, alpha, top, top + blockH)
        }

        // ---- date + AM/PM
        val ds = w * (0.040f + 0.018f * base) * (s.dateSize / 100f)
        val dateArabic = Lang.dateCode(s.dateLang) != "en"
        datePaint.letterSpacing = if (dateArabic) 0f else 0.02f
        datePaint.typeface = if (s.dateClockFont) tf else Typeface.create("sans-serif-medium", Typeface.NORMAL)
        resetPaint(datePaint)
        datePaint.textSize = ds
        datePaint.color = s.color
        datePaint.alpha = (alpha * 0.9f).toInt()
        if (s.shadow) {
            datePaint.setShadowLayer(w * 0.012f, 0f, w * 0.004f, 0x66000000)
        } else {
            datePaint.clearShadowLayer()
        }

        var belowY = top + blockH
        var rTop = top
        var rBottom = top + blockH
        var rHalf = minOf(widest, maxW) / 2f
        if (!s.use24h && s.showAmPm) {
            belowY += ds * 1.5f
            c.drawText(Lang.ampm(cal.get(Calendar.AM_PM) == Calendar.AM, s.dateLang), cx, belowY, datePaint)
            rBottom = belowY + ds * 0.3f
        }
        if (s.showDate) {
            var text = dateText(cal, s)
            if (s.dateUpper) text = text.uppercase(Lang.localeFor(s.dateLang))
            text = Numerals.convert(latinDigits(text), s.numerals)
            rHalf = maxOf(rHalf, datePaint.measureText(text) / 2f)
            if (s.datePos == 0) {
                val baseline = top - ds * 0.7f
                c.drawText(text, cx, baseline, datePaint)
                rTop = baseline - ds * 1.05f
            } else {
                belowY += ds * 1.5f
                c.drawText(text, cx, belowY, datePaint)
                rBottom = belowY + ds * 0.3f
            }
        }
        datePaint.clearShadowLayer()
        clockRect.set(cx - rHalf, rTop, cx + rHalf, rBottom)
    }

    private fun latinDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            if (Character.isDigit(ch)) sb.append(('0'.code + Character.digit(ch, 10)).toChar()) else sb.append(ch)
        }
        return sb.toString()
    }

    private fun dateText(cal: Calendar, s: ClockSettings): String {
        val skeleton = when (s.dateFormat) {
            1 -> "EEEdMMM"
            2 -> "dMMMM"
            3 -> "EEEE"
            else -> "EEEEdMMMM"
        }
        val loc = Lang.localeFor(s.dateLang)
        val pattern = DateFormat.getBestDateTimePattern(loc, skeleton)
        return java.text.SimpleDateFormat(pattern, loc).format(cal.time)
    }
}

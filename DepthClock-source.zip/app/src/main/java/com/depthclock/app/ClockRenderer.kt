package com.depthclock.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.format.DateFormat
import java.util.Calendar
import java.util.Locale

object Fonts {
    val names = listOf("Thin", "Light", "Regular", "Medium", "Bold", "Black", "Condensed", "Serif", "Mono", "Casual")

    fun typeface(i: Int): Typeface = when (i) {
        0 -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
        1 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        2 -> Typeface.create("sans-serif", Typeface.NORMAL)
        3 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
        4 -> Typeface.create("sans-serif", Typeface.BOLD)
        5 -> Typeface.create("sans-serif-black", Typeface.NORMAL)
        6 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
        7 -> Typeface.create("serif", Typeface.BOLD)
        8 -> Typeface.create("monospace", Typeface.BOLD)
        else -> Typeface.create("casual", Typeface.NORMAL)
    }
}

/**
 * Draws three layers, back to front:
 *   1. background photo
 *   2. the clock
 *   3. the cut-out subject (so the clock appears BEHIND it)
 * px/py in [-1, 1] move the layers in opposite directions to fake depth.
 */
class ClockRenderer {
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val ovPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val fallbackPaint = Paint()
    private val dst = RectF()
    private val bounds = Rect()
    private var fallbackH = -1

    fun draw(
        c: Canvas, w: Int, h: Int, s: ClockSettings,
        bg: Bitmap?, fg: Bitmap?, ov: Bitmap?, px: Float, py: Float, now: Long
    ) {
        if (w <= 0 || h <= 0) return
        val wf = w.toFloat()
        val hf = h.toFloat()
        val strength = s.parallax / 100f
        val amp = wf * 0.03f * strength
        val scale = 1f + amp / wf        // enough overscan so edges never show
        val maxShift = amp * 0.5f
        val sx = px * maxShift
        val sy = py * maxShift

        if (bg != null) {
            layer(c, bg, wf, hf, scale, -sx, -sy)
        } else {
            drawFallback(c, wf, hf)
        }
        // transparent overlay sitting just above the photo (behind the clock)
        if (ov != null && s.overlayEnabled && !s.overlayFront) {
            drawOverlay(c, ov, wf, hf, s, scale, -sx * 0.5f, -sy * 0.5f)
        }
        drawClock(c, wf, hf, s, now)
        if (fg != null && s.depthEnabled) {
            layer(c, fg, wf, hf, scale, sx, sy)
        }
        // or in front of everything, including the subject
        if (ov != null && s.overlayEnabled && s.overlayFront) {
            drawOverlay(c, ov, wf, hf, s, scale, sx, sy)
        }
    }

    private fun drawOverlay(
        c: Canvas, ov: Bitmap, w: Float, h: Float, s: ClockSettings,
        scale: Float, dx: Float, dy: Float
    ) {
        val fit = minOf(w / ov.width, h / ov.height) * (s.overlayScale / 100f)
        val ow = ov.width * fit
        val oh = ov.height * fit
        val cx = w * s.overlayX / 100f
        val cy = h * s.overlayY / 100f
        ovPaint.alpha = (255 * s.overlayOpacity / 100f).toInt().coerceIn(0, 255)
        c.save()
        c.translate(dx, dy)
        c.scale(scale, scale, w / 2f, h / 2f)
        dst.set(cx - ow / 2f, cy - oh / 2f, cx + ow / 2f, cy + oh / 2f)
        c.drawBitmap(ov, null, dst, ovPaint)
        c.restore()
    }

    private fun layer(c: Canvas, bmp: Bitmap, w: Float, h: Float, scale: Float, dx: Float, dy: Float) {
        c.save()
        c.translate(dx, dy)
        c.scale(scale, scale, w / 2f, h / 2f)
        dst.set(0f, 0f, w, h)
        c.drawBitmap(bmp, null, dst, bitmapPaint)
        c.restore()
    }

    private fun drawFallback(c: Canvas, w: Float, h: Float) {
        if (fallbackH != h.toInt()) {
            fallbackH = h.toInt()
            fallbackPaint.shader = LinearGradient(
                0f, 0f, 0f, h,
                intArrayOf(0xFF141E30.toInt(), 0xFF35577D.toInt(), 0xFF6B7B8C.toInt()),
                null, Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, w, h, fallbackPaint)
    }

    private fun drawClock(c: Canvas, w: Float, h: Float, s: ClockSettings, now: Long) {
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        val hour: String = if (s.use24h) {
            String.format(Locale.US, "%02d", cal.get(Calendar.HOUR_OF_DAY))
        } else {
            val hh = cal.get(Calendar.HOUR)
            (if (hh == 0) 12 else hh).toString()
        }
        val min = String.format(Locale.US, "%02d", cal.get(Calendar.MINUTE))
        val base = s.sizePct / 100f
        val alpha = (255 * s.opacity / 100f).toInt().coerceIn(0, 255)

        timePaint.typeface = Fonts.typeface(s.font)
        timePaint.color = s.color
        timePaint.alpha = alpha
        if (s.shadow) {
            timePaint.setShadowLayer(w * 0.02f, 0f, w * 0.008f, 0x66000000)
        } else {
            timePaint.clearShadowLayer()
        }

        var ts = if (s.stacked) w * (0.20f + 0.50f * base) else w * (0.12f + 0.30f * base)
        timePaint.textSize = ts
        val oneLine = "$hour:$min"
        val widest = if (s.stacked) {
            maxOf(timePaint.measureText(hour), timePaint.measureText(min))
        } else {
            timePaint.measureText(oneLine)
        }
        val maxW = w * 0.92f
        if (widest > maxW) {
            ts *= maxW / widest
            timePaint.textSize = ts
        }

        timePaint.getTextBounds("0", 0, 1, bounds)
        val dh = bounds.height().toFloat()
        val cx = w / 2f
        val cy = h * s.posY / 100f
        val top: Float

        if (s.stacked) {
            val gap = dh * 0.10f
            val blockH = dh * 2f + gap
            top = cy - blockH / 2f
            c.drawText(hour, cx, top + dh, timePaint)
            c.drawText(min, cx, top + dh * 2f + gap, timePaint)
        } else {
            top = cy - dh / 2f
            c.drawText(oneLine, cx, top + dh, timePaint)
        }

        if (s.showDate) {
            val ds = w * (0.040f + 0.018f * base)
            datePaint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            datePaint.textSize = ds
            datePaint.color = s.color
            datePaint.alpha = (alpha * 0.9f).toInt()
            if (s.shadow) {
                datePaint.setShadowLayer(w * 0.012f, 0f, w * 0.004f, 0x66000000)
            } else {
                datePaint.clearShadowLayer()
            }
            val pattern = DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEEdMMMM")
            val text = DateFormat.format(pattern, cal).toString()
            c.drawText(text, cx, top - ds * 0.7f, datePaint)
        }
    }
}

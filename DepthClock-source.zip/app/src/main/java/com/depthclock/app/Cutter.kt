package com.depthclock.app

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.nio.FloatBuffer
import java.util.concurrent.TimeUnit
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Refined, pre-curve alpha at working resolution (0..255 per pixel). */
class RawCut(val alpha: ByteArray, val w: Int, val h: Int, val engine: String)

/**
 * The "smart cut" pipeline:
 *  1. AI finds the subject (Google subject segmentation, falling back to the bundled person model)
 *  2. stray blobs are removed and tiny holes are filled
 *  3. an edge-aware guided filter snaps the mask to the real edges of the photo
 *  4. the user's softness / shift curve is applied at full resolution
 */
object Cutter {
    const val ENGINE_AUTO = 0
    const val ENGINE_SUBJECT = 1
    const val ENGINE_PERSON = 2

    private const val WORK = 1280

    @Volatile
    var lastError: String = ""

    fun cut(src: Bitmap, engine: Int): RawCut? {
        lastError = ""
        val k = min(1f, WORK.toFloat() / max(src.width, src.height))
        val ww = max(2, (src.width * k).roundToInt())
        val wh = max(2, (src.height * k).roundToInt())
        val work = if (ww == src.width && wh == src.height) src else Bitmap.createScaledBitmap(src, ww, wh, true)

        val order = when (engine) {
            ENGINE_PERSON -> listOf(false)
            ENGINE_SUBJECT -> listOf(true, false)
            else -> listOf(true, false)
        }

        var conf: FloatArray? = null
        var used = ""
        for (subject in order) {
            val c = (if (subject) subjectMask(work) else personMask(work)) ?: continue
            val frac = coverage(c)
            if (frac < 0.005f || frac > 0.95f) {
                lastError = "no clear subject found"
                continue
            }
            conf = c
            used = if (subject) "any-subject model" else "person model"
            break
        }
        if (conf == null) {
            if (work !== src) work.recycle()
            return null
        }

        // sharpen the model's confidence a little before cleaning it up
        for (i in conf.indices) conf[i] = ((conf[i] - 0.5f) * 1.5f + 0.5f).coerceIn(0f, 1f)
        cleanup(conf, ww, wh)

        val n = ww * wh
        val px = IntArray(n)
        work.getPixels(px, 0, ww, 0, 0, ww, wh)
        val gray = FloatArray(n)
        for (i in 0 until n) {
            val c = px[i]
            gray[i] = (0.299f * ((c shr 16) and 0xFF) + 0.587f * ((c shr 8) and 0xFF) + 0.114f * (c and 0xFF)) / 255f
        }
        if (work !== src) work.recycle()

        val radius = max(3, max(ww, wh) / 150)
        val q = guided(gray, conf, ww, wh, radius, 0.0004f)
        val out = ByteArray(n)
        for (i in 0 until n) out[i] = (q[i].coerceIn(0f, 1f) * 255f + 0.5f).toInt().toByte()
        return RawCut(out, ww, wh, used)
    }

    /** Turns [src] into an ARGB bitmap whose alpha is the AI cut-out, shaped by softness / shift. */
    fun applyAlpha(src: Bitmap, raw: RawCut, softness: Int, shift: Int): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val aw = raw.w
        val ah = raw.h
        val a = raw.alpha

        val t = 0.5f - shift / 200f
        val half = 0.04f + softness / 100f * 0.40f
        val lo = t - half
        val inv = 1f / (2f * half)

        val x0 = IntArray(w)
        val x1 = IntArray(w)
        val xf = FloatArray(w)
        for (x in 0 until w) {
            val g = ((x + 0.5f) * aw / w - 0.5f).coerceIn(0f, (aw - 1).toFloat())
            val i0 = floor(g).toInt()
            x0[x] = i0
            x1[x] = min(i0 + 1, aw - 1)
            xf[x] = g - i0
        }
        for (y in 0 until h) {
            val g = ((y + 0.5f) * ah / h - 0.5f).coerceIn(0f, (ah - 1).toFloat())
            val j0 = floor(g).toInt()
            val j1 = min(j0 + 1, ah - 1)
            val yf = g - j0
            val r0 = j0 * aw
            val r1 = j1 * aw
            val row = y * w
            for (x in 0 until w) {
                val fx = xf[x]
                val top = (a[r0 + x0[x]].toInt() and 0xFF) * (1f - fx) + (a[r0 + x1[x]].toInt() and 0xFF) * fx
                val bot = (a[r1 + x0[x]].toInt() and 0xFF) * (1f - fx) + (a[r1 + x1[x]].toInt() and 0xFF) * fx
                val v = (top * (1f - yf) + bot * yf) / 255f
                val s = smooth((v - lo) * inv)
                val alpha = (s * 255f + 0.5f).toInt()
                px[row + x] = (alpha shl 24) or (px[row + x] and 0x00FFFFFF)
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Crops away fully transparent borders. */
    fun trimTransparent(bmp: Bitmap): Bitmap {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if ((px[row + x] ushr 24) > 6) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return bmp
        val m = 2
        val l = max(0, minX - m)
        val t = max(0, minY - m)
        val r = min(w - 1, maxX + m)
        val b = min(h - 1, maxY + m)
        if (l == 0 && t == 0 && r == w - 1 && b == h - 1) return bmp
        return Bitmap.createBitmap(bmp, l, t, r - l + 1, b - t + 1)
    }

    /** True when the image really has see-through pixels (not just an unused alpha channel). */
    fun hasTransparency(bmp: Bitmap): Boolean {
        if (!bmp.hasAlpha()) return false
        val small = Bitmap.createScaledBitmap(bmp, 96, 96, false)
        val px = IntArray(96 * 96)
        small.getPixels(px, 0, 96, 0, 0, 96, 96)
        small.recycle()
        var see = 0
        for (c in px) if ((c ushr 24) < 250) see++
        return see > px.size / 200
    }

    // ------------------------------------------------------------ storage

    fun save(raw: RawCut, f: File) {
        DataOutputStream(f.outputStream().buffered()).use {
            it.writeInt(raw.w)
            it.writeInt(raw.h)
            it.writeUTF(raw.engine)
            it.write(raw.alpha)
        }
    }

    fun load(f: File): RawCut? {
        if (!f.exists()) return null
        return try {
            DataInputStream(f.inputStream().buffered()).use {
                val w = it.readInt()
                val h = it.readInt()
                val e = it.readUTF()
                val a = ByteArray(w * h)
                it.readFully(a)
                RawCut(a, w, h, e)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------ AI engines

    private fun subjectMask(work: Bitmap): FloatArray? {
        val seg = SubjectSegmentation.getClient(
            SubjectSegmenterOptions.Builder().enableForegroundConfidenceMask().build()
        )
        return try {
            val res = Tasks.await(seg.process(InputImage.fromBitmap(work, 0)), 45, TimeUnit.SECONDS)
            val buf = res.foregroundConfidenceMask
            if (buf == null) null else bufferToMask(buf, work.width, work.height)
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            null
        } finally {
            seg.close()
        }
    }

    private fun personMask(work: Bitmap): FloatArray? {
        val seg = Segmentation.getClient(
            SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .build()
        )
        return try {
            val mask = Tasks.await(seg.process(InputImage.fromBitmap(work, 0)), 45, TimeUnit.SECONDS)
            val buf = mask.buffer
            val arr = FloatArray(mask.width * mask.height)
            buf.rewind()
            buf.get(arr)
            if (mask.width == work.width && mask.height == work.height) arr
            else resample(arr, mask.width, mask.height, work.width, work.height)
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            null
        } finally {
            seg.close()
        }
    }

    private fun bufferToMask(buf: FloatBuffer, ww: Int, wh: Int): FloatArray? {
        buf.rewind()
        val n = buf.remaining()
        if (n <= 0) return null
        val arr = FloatArray(n)
        buf.get(arr)
        if (n == ww * wh) return arr
        val mw = sqrt(n.toDouble() * ww / wh).roundToInt().coerceAtLeast(1)
        val mh = n / mw
        if (mw * mh != n) return null
        return resample(arr, mw, mh, ww, wh)
    }

    private fun coverage(c: FloatArray): Float {
        var k = 0
        for (v in c) if (v > 0.5f) k++
        return k.toFloat() / c.size
    }

    private fun resample(src: FloatArray, sw: Int, sh: Int, dw: Int, dh: Int): FloatArray {
        val out = FloatArray(dw * dh)
        for (y in 0 until dh) {
            val gy = ((y + 0.5f) * sh / dh - 0.5f).coerceIn(0f, (sh - 1).toFloat())
            val y0 = floor(gy).toInt()
            val y1 = min(y0 + 1, sh - 1)
            val fy = gy - y0
            for (x in 0 until dw) {
                val gx = ((x + 0.5f) * sw / dw - 0.5f).coerceIn(0f, (sw - 1).toFloat())
                val x0 = floor(gx).toInt()
                val x1 = min(x0 + 1, sw - 1)
                val fx = gx - x0
                val top = src[y0 * sw + x0] * (1f - fx) + src[y0 * sw + x1] * fx
                val bot = src[y1 * sw + x0] * (1f - fx) + src[y1 * sw + x1] * fx
                out[y * dw + x] = top * (1f - fy) + bot * fy
            }
        }
        return out
    }

    // ------------------------------------------------------------ clean-up

    private class Comps(val label: IntArray, val area: IntArray, val border: BooleanArray)

    private fun components(p: FloatArray, w: Int, h: Int, wantFg: Boolean): Comps {
        val n = w * h
        val label = IntArray(n)
        val areas = ArrayList<Int>()
        val border = ArrayList<Boolean>()
        areas.add(0)
        border.add(false)
        val stack = IntArray(n)
        var next = 1
        for (i in 0 until n) {
            if (label[i] != 0) continue
            if ((p[i] > 0.5f) != wantFg) continue
            var sp = 0
            stack[sp++] = i
            label[i] = next
            var area = 0
            var touch = false
            while (sp > 0) {
                val cur = stack[--sp]
                area++
                val x = cur % w
                val y = cur / w
                if (x == 0 || y == 0 || x == w - 1 || y == h - 1) touch = true
                if (x > 0) {
                    val j = cur - 1
                    if (label[j] == 0 && (p[j] > 0.5f) == wantFg) { label[j] = next; stack[sp++] = j }
                }
                if (x < w - 1) {
                    val j = cur + 1
                    if (label[j] == 0 && (p[j] > 0.5f) == wantFg) { label[j] = next; stack[sp++] = j }
                }
                if (y > 0) {
                    val j = cur - w
                    if (label[j] == 0 && (p[j] > 0.5f) == wantFg) { label[j] = next; stack[sp++] = j }
                }
                if (y < h - 1) {
                    val j = cur + w
                    if (label[j] == 0 && (p[j] > 0.5f) == wantFg) { label[j] = next; stack[sp++] = j }
                }
            }
            areas.add(area)
            border.add(touch)
            next++
        }
        return Comps(label, areas.toIntArray(), border.toBooleanArray())
    }

    /** Drops small stray blobs and fills tiny pin-holes inside the subject. */
    private fun cleanup(p: FloatArray, w: Int, h: Int) {
        val n = w * h
        val fg = components(p, w, h, true)
        var biggest = 0
        for (a in fg.area) if (a > biggest) biggest = a
        val drop = BooleanArray(fg.area.size)
        for (id in 1 until fg.area.size) {
            val a = fg.area[id]
            if (a < n * 0.004f && a < biggest * 0.25f) drop[id] = true
        }
        for (i in 0 until n) {
            val l = fg.label[i]
            if (l != 0 && drop[l]) p[i] = 0f
        }
        val bg = components(p, w, h, false)
        for (i in 0 until n) {
            val l = bg.label[i]
            if (l != 0 && !bg.border[l] && bg.area[l] < n * 0.001f) p[i] = 1f
        }
    }

    // ------------------------------------------------------------ guided filter

    private fun box(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(w * h)
        val out = FloatArray(w * h)
        val pre = DoubleArray(max(w, h) + 1)
        for (y in 0 until h) {
            val row = y * w
            pre[0] = 0.0
            for (x in 0 until w) pre[x + 1] = pre[x] + src[row + x]
            for (x in 0 until w) {
                val lo = max(0, x - r)
                val hi = min(w - 1, x + r)
                tmp[row + x] = ((pre[hi + 1] - pre[lo]) / (hi - lo + 1)).toFloat()
            }
        }
        for (x in 0 until w) {
            pre[0] = 0.0
            for (y in 0 until h) pre[y + 1] = pre[y] + tmp[y * w + x]
            for (y in 0 until h) {
                val lo = max(0, y - r)
                val hi = min(h - 1, y + r)
                out[y * w + x] = ((pre[hi + 1] - pre[lo]) / (hi - lo + 1)).toFloat()
            }
        }
        return out
    }

    /** Edge-aware smoothing of [p] that follows the edges of [guide] (He et al., guided filter). */
    private fun guided(guide: FloatArray, p: FloatArray, w: Int, h: Int, r: Int, eps: Float): FloatArray {
        val n = w * h
        val meanI = box(guide, w, h, r)
        val meanP = box(p, w, h, r)
        val ii = FloatArray(n)
        val ip = FloatArray(n)
        for (k in 0 until n) {
            ii[k] = guide[k] * guide[k]
            ip[k] = guide[k] * p[k]
        }
        val corrI = box(ii, w, h, r)
        val corrIp = box(ip, w, h, r)
        val a = FloatArray(n)
        val b = FloatArray(n)
        for (k in 0 until n) {
            val varI = corrI[k] - meanI[k] * meanI[k]
            val cov = corrIp[k] - meanI[k] * meanP[k]
            val ak = cov / (varI + eps)
            a[k] = ak
            b[k] = meanP[k] - ak * meanI[k]
        }
        val meanA = box(a, w, h, r)
        val meanB = box(b, w, h, r)
        val q = FloatArray(n)
        for (k in 0 until n) q[k] = meanA[k] * guide[k] + meanB[k]
        return q
    }

    private fun smooth(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }
}
